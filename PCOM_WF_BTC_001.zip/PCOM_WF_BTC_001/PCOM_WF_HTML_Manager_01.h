

#ifndef	_PCOM_WF_HTML_Manager_h_   // garante processamento unico.
#define	_PCOM_WF_HTML_Manager_h_


// **********************************************************************
// **********************************************************************
// **
// **	Implementacao de um mecanismo sistematico para gerenciamento
// **	de Paginas HTML em um ESP32 configurado como WiFi Server. O
// **	mecanismo permite facilmente gerenciar uma grande quantidade
// **	de Paginas HTML, respondendo a comandos e atualizando paginas
// **	de acordo com estes comandos.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Definicao das Bibliotecas do ESP32 utilizadas neste Sistema:
//=======================================================================

#include "WiFi.h"   // Lib WiFi para o ESP32.

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Interface para o Mecanismo de Gerenciamento de Paginas HTML
//	para um Cliente WiFi.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao de um "tipo Ponteiro" para uma funcao que trata uma
//	requisicao de um Cliente WiFi. A funcao pode interpretar os
//	comandos recebidos na requisicao, e enviar ou atualizar Paginas
//	HTML conforme necessario. O Cliente pode ser um Navegador em um
//	Computador, Tablet, Smartphone, ou qualquer outro dispositivo
//	com um protocolo dedicado (encapsulado no TCP/IP).
//	A funcao sera' chamada atraves de um mecanismo semelhante a um
//	"callback", quando uma requisicao e' enviada pelo Cliente WiFi.
//=======================================================================

typedef void (*HTML_Proc_func) ( WiFiClient* HTML_client_PTR, String* HTML_req_PTR );

//***********************************************************************




//***********************************************************************
//	Seta o Timeout para atendimento a um Cliente HTML. O periodo
//	e' especificado em unidades de segundos, para facilidade de
//	utilizacao da rotina. O Timeout pode ser alterado a qualquer
//	momento ("on the fly").
//=======================================================================

void	WF_HTML_timeout_set ( unsigned short timeout );

//***********************************************************************




//***********************************************************************
//	Implementacao do Mecanismo para Gerenciamento de Paginas HTML
//	de um Cliente conectado via WiFi. Essencialmente, a rotina
//	gerencia a recepcao de requisicoes do Cliente (se um estiver
//	conectado). Quando uma requisicao e' completada, a rotina entao
//	chama a funcao que ira' processar a requisicao do Cliente,
//	passando para esta funcao a string correspondente a requisicao
//	(esta string normalmente e' enviada pelo navegador utilizado
//	pelo Cliente). A funcao a ser chamada (em um formato semelhante
//	a um "callback"), e' passada para esta rotina por quem chamou a
//	mesma, juntamente com o Cliente atual. Um timeout tambem esta'
//	implementado, caso o Cliente nao conclua a requisicao iniciada.
//	Quando o timeout ocorre, a requisicao e' descartada e a conexao
//	com o Cliente e' fechada, mas podera' ser reaberta se o Cliente
//	reconectar. Na saida, a rotina informa se alguma requisicao foi
//	recebida.
//=======================================================================

bool	WF_HTML_Manager ( WiFiClient* client_PTR, HTML_Proc_func HTML_Proc_PTR );

//***********************************************************************



#endif	// _PCOM_WF_HTML_Manager_h_

