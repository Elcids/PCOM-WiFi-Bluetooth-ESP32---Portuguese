

#ifndef	new_BTC_Serial_LIB_list    // garante compilacao unica.
#define	new_BTC_Serial_LIB_list


// **********************************************************************
// **********************************************************************
// **
// **	Declaracao das LIBs utilizadas no Gerenciamento da Interface
// **	SPP (Serial Port Profile) Bluetooth para o ESP32, para a
// **	Plataforma Arduino.
// **
// **	Baseada na LIB "BluetoothSerial" do SDK 1.0.0 da Espressif.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************



#if defined( CONFIG_BT_ENABLED ) && defined( CONFIG_BLUEDROID_ENABLED )



//***********************************************************************
//	LIBs basicas da Plataforma ESP32:
//=======================================================================

#include "sdkconfig.h"
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

//***********************************************************************




//***********************************************************************
//	LIBs relacionadas a Plataforma Arduino:
//=======================================================================

#ifdef	ARDUINO_ARCH_ESP32
#include "esp32-hal-log.h"
#endif

//-----------------------------------------------------------------------

#include "Arduino.h"
#include "Stream.h"

//***********************************************************************




//***********************************************************************
//	LIBs da API para o Bluetooth do ESP32:
//=======================================================================

#include "esp_bt.h"
#include "esp_bt_main.h"
#include "esp_gap_bt_api.h"
#include "esp_bt_device.h"
#include "esp_spp_api.h"
#include <esp_log.h>

//***********************************************************************



#else	// defined( CONFIG_BT_ENABLED ) && defined( CONFIG_BLUEDROID_ENABLED )

#error	CONFIG_BT_ENABLED e CONFIG_BLUEDROID_ENABLED estao desabilitados!   // indica o erro no tempo de compilacao.

#endif	// defined( CONFIG_BT_ENABLED ) && defined( CONFIG_BLUEDROID_ENABLED )



#endif	// new_BTC_Serial_LIB_list

