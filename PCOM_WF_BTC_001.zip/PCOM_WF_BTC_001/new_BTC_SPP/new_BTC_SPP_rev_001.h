

#ifndef	_new_BTC_SPP_rev_001_h_   // garante compilacao unica.
#define	_new_BTC_SPP_rev_001_h_


// **********************************************************************
// **********************************************************************
// **
// **	Interface para a Classe "BTC_Serial", para o Gerenciamento de
// **	uma SPP (Serial Port Profile) Bluetooth para o ESP32, para a
// **	Plataforma Arduino.
// **
// **	Baseada na LIB "BluetoothSerial" do SDK 1.0.0 da Espressif.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Inclusao do Arquivo com a declaracao das LIBs utilizadas
//	nesta Classe:
//=======================================================================

#include "new_BTC_SPP_LIB_list_rev_001.h"   // lista de LIBs utilizadas.

//***********************************************************************




//***********************************************************************
//	Definicao de um tipo Vetor para acondicionar os 6 Bytes do
//	numero "PIN" unico para um dispositivo Bluetooth qualquer:
//=======================================================================

typedef	uint8_t BTC_Client_PIN_type [6];   // 6 Bytes do numero "PIN".

//***********************************************************************




//***********************************************************************
//	Declaracao e definicao da Classe "BTC_Serial" para a Interface
//	com o codigo aplicativo principal:
//=======================================================================

class BTC_Serial: public Stream		// Classe "BTC_Serial":
{
public:		// membros publicos para a Interface:

	BTC_Serial();	// Constructor da Classe.

	~BTC_Serial();	// Destructor da Classe (ver detalhes importantes na implementacao).

	bool begin( String name = String() );	// inicia a SPP com nome do Dispositivo Bluetooth.

	bool BTC_deinit();	// "desinicializa" a SPP iniciada via metodo "begin".

	bool hasClient();	// verifica se ha' um Cliente conectado na SPP.

	bool Client_PIN_get( BTC_Client_PIN_type* Client_PIN_PTR );   // le o numero "PIN" do Cliente conectado.

	int available();	// verifica e retorna o total de Bytes enviados pelo Cliente.

	int peek();	// le uma copia do proximo Byte recebido, sem retirar do "Queue" de recepcao.

	int read();	// le o proximo Byte recebido, retirando este do "Queue" de recepcao.

	size_t write( uint8_t c );   // envia o Byte especificado, ao Cliente atual, via SPP.

	size_t write( const uint8_t* Buffer, size_t size );   // envia o Vetor de Bytes especificado, via SPP.

	void flush();	// metodo mantido apenas pela exigencia da Classe "Stream".

	bool disconnect();   // faz desconexao do Cliente atualmente conectado via SPP.

	void end();	// equivalente ao Destructor da Classe (ver detalhes importantes na implementacao).

	uint8_t Event;	// indica o Evento sinalizado por esta Implementacao.


private:	// membros exclusivos da Classe, nao disponiveis na Interface:

	static uint32_t BTC_SPP_client;   // identificador interno do Cliente SPP atual.

	static BTC_Client_PIN_type BTC_Client_PIN;   // vetor "PIN" do Cliente SPP atual.

	static xQueueHandle BTC_RX_Queue;   // Queue para recepcao de Bytes do Cliente SPP.

	static void BTC_SPP_cb ( esp_spp_cb_event_t event, esp_spp_cb_param_t* param );   // callback para o SPP.

	static bool BTC_SPP_init ( const char* name );	// inicializa o SPP.

	static bool BTC_SPP_stop();	// fecha o SPP (em definitivo).
};
//***********************************************************************




//***********************************************************************
//	Definicao dos Eventos sinalizados nesta Classe:
//=======================================================================

enum	BTC_EVENTS
{
	BTC_EVENT_none,   // indica que nao ocorreu Evento.

};
//***********************************************************************




//***********************************************************************
//	Definicao de um tipo Ponteiro para acessar a instancia do SPP
//	Bluetooth. Isto e' necessario devido a grande quantidade de
//	memoria utilizada pela implementacao atual da LIB Bluetooth
//	da Espressif. Este montante de memoria, torna proibitivo que
//	se tenha mais de uma instancia do SPP no Sistema. Logo, o tipo
//	Ponteiro aqui definido pode ser usado como interface para a
//	SPP instanciada quando o construtor da Classe for executado.
//=======================================================================

typedef	BTC_Serial*  BLUE_Device_PTR;  // tipo para acesso ao SSP Bluetooth.

//***********************************************************************




#endif	// _new_BTC_SPP_rev_001_h_

