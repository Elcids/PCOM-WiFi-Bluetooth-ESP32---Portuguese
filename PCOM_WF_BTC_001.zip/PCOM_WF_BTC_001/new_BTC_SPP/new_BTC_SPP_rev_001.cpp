

#ifndef	_new_BTC_SPP_rev_001_cpp_   // garante compilacao unica.
#define	_new_BTC_SPP_rev_001_cpp_


// **********************************************************************
// **********************************************************************
// **
// **	Implementacao da Classe "BTC_Serial", para o Gerenciamento de
// **	uma SPP (Serial Port Profile) Bluetooth para o ESP32, para a
// **	Plataforma Arduino.
// **
// **	Baseada na LIB "BluetoothSerial" do SDK 1.0.0 da Espressif.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Arquivos de include utilizados:
//=======================================================================

#include "new_BTC_SPP_rev_001.h"   // header com definicoes e prototipos.

//***********************************************************************




//***********************************************************************
//	Definicoes para identificacao e comunicacao com um Cliente da
//	Interface SPP Bluetooth:
//=======================================================================

uint32_t BTC_Serial::BTC_SPP_client = 0;   // ID interno do Cliente SPP atual.

BTC_Client_PIN_type BTC_Serial::BTC_Client_PIN = { 0, 0, 0, 0, 0, 0 };	// "PIN" do Cliente SPP atual.

//-----------------------------------------------------------------------

const char* BTC_SPP_server_name = "BTC_SPP_SERVER";   // nome do Server para o SPP.

//***********************************************************************




//***********************************************************************
//	Definicoes e instanciamento de um Queue para recepcao (RX) de
//	Bytes via Interface SPP Bluetooth:
//=======================================================================

#define BTC_RX_Qsize  256	// tamanho do Queue de recepcao via SPP.

//-----------------------------------------------------------------------

xQueueHandle BTC_Serial::BTC_RX_Queue = xQueueCreate( BTC_RX_Qsize, 1 );   // instacia o RX Queue SPP.

//***********************************************************************




//***********************************************************************
//	Rotina de callback para tratamento dos eventos do SPP Bluetooth.
//=======================================================================

void	BTC_Serial::BTC_SPP_cb ( esp_spp_cb_event_t event, esp_spp_cb_param_t* param )
{
//--------------------------------------------------
int i;
//--------------------------------------------------

	switch ( event )   // conforme o evento ocorrido:
	{
//..................................................

		case ESP_SPP_INIT_EVT:	// se foi um "init" do SPP:

			log_i("ESP_SPP_INIT_EVT");   // log para depuracao.

			esp_bt_gap_set_scan_mode( ESP_BT_SCAN_MODE_CONNECTABLE_DISCOVERABLE );	// seta o "scan mode" do Bluetooth.

			esp_spp_start_srv( ESP_SPP_SEC_NONE, ESP_SPP_ROLE_SLAVE, 0, BTC_SPP_server_name );   // inicia o SPP Server.
		break;

//..................................................

		case ESP_SPP_DISCOVERY_COMP_EVT:   // se completou a varredura:

			log_i("ESP_SPP_DISCOVERY_COMP_EVT");	// log para depuracao.
		break;

//..................................................

		case ESP_SPP_OPEN_EVT:   // se um Client abriu uma conexao SPP:

			log_i("ESP_SPP_OPEN_EVT");   // log para depuracao.
		break;

//..................................................

		case ESP_SPP_CLOSE_EVT:   // se um Client abriu a conexao SPP:

			BTC_SPP_client = 0;	// indica que nao ha' Cliente SPP.

			log_i("ESP_SPP_CLOSE_EVT");	// log para depuracao.
		break;

//..................................................

		case ESP_SPP_START_EVT:   // se o SPP Server foi iniciado:

			log_i("ESP_SPP_START_EVT");	// log para depuracao.
		break;

//..................................................

		case ESP_SPP_CL_INIT_EVT:   // se um Cliente iniciou uma conexao SPP:

			log_i("ESP_SPP_CL_INIT_EVT");	// log para depuracao.
		break;

//..................................................

		case ESP_SPP_DATA_IND_EVT:   // se recebeu algum dado via Cliente SPP:

			log_v( "ESP_SPP_DATA_IND_EVT len=%d handle=%d", param->data_ind.len, param->data_ind.handle );	// log para depuracao.

//			esp_log_buffer_hex( "", param->data_ind.data, param->data_ind.len );   // log para depuracao.

			if ( BTC_RX_Queue != NULL )	// se o Queue foi instanciado:
			{
				for ( i = 0; i < param->data_ind.len; i++ )   // para cada Byte recebido via SPP:
				{
					xQueueSend( BTC_RX_Queue, param->data_ind.data + i, (TickType_t) 0 );	// insere este Byte no RX Queue.
				}
			}
			else	log_e("SerialQueueBT ERROR");	// log para depuracao.

		break;

//..................................................

		case ESP_SPP_CONG_EVT:   // se mudou o estado de congestionamento no SPP:

			log_i("ESP_SPP_CONG_EVT");   // log para depuracao.
		break;

//..................................................

		case ESP_SPP_WRITE_EVT:   // se completou uma operacao de envio para o Cliente SPP:

			log_v("ESP_SPP_WRITE_EVT");	// log para depuracao.
		break;

//..................................................

		case ESP_SPP_SRV_OPEN_EVT:   // se foi aberta uma conexao com o SPP Server:

			if ( BTC_SPP_client == 0 )   // se nao ha' Cliente ja' conectado:
			{
				BTC_SPP_client = param->open.handle;	// obtem ID interno do Cliente SPP atual.

				for ( i = 0; i < 6; i++ )   // le os 6 bytes do ID do Cliente SPP:
				{
					BTC_Client_PIN[i] = param->srv_open.rem_bda[i];   // le cada Byte do ID do Cliente SPP.
				}
			}

			log_i("ESP_SPP_SRV_OPEN_EVT");	// log para depuracao.
		break;

//..................................................
	}
}
//***********************************************************************




//***********************************************************************
//	Inicializa a Interface SPP Bluetooth, para permitir a conexao
//	de um Cliente SPP, possibilitando comunicacao com este.
//=======================================================================

bool	BTC_Serial::BTC_SPP_init ( const char* name )
{
//--------------------------------------------------
esp_bluedroid_status_t bt_state;
esp_bt_cod_t cod;
//--------------------------------------------------

	if ( !btStarted() && !btStart() )   // se o Modulo BT nao foi iniciado:
	{
		log_e("%s initialize controller failed\n", __func__);	// log para depuracao.

		return (false);   // finaliza indicando a falha.
	}

//..................................................

	bt_state = esp_bluedroid_get_status();	// obtem o status do "BLUEDROID".

//..................................................

	if ( bt_state == ESP_BLUEDROID_STATUS_UNINITIALIZED )	// se o "BLUEDROID" nao foi inicializado:
	{
		if ( esp_bluedroid_init() )	// se nao conseguir inicializar o "BLUEDROID":
		{
			log_e("%s initialize bluedroid failed\n", __func__);	// log para depuracao.

			return (false);   // finaliza indicando a falha.
		}
	}

//..................................................

	if ( bt_state != ESP_BLUEDROID_STATUS_ENABLED )   // se o "BLUEDROID" esta' desabilitado:
	{
		if ( esp_bluedroid_enable() )	// se nao conseguir habilitar o "BLUEDROID":
		{
			log_e("%s enable bluedroid failed\n", __func__);   // log para depuracao.

			return (false);   // finaliza indicando a falha.
		}
	}

//..................................................

	if ( esp_spp_register_callback( BTC_SPP_cb ) != ESP_OK )   // se nao conseguir setar o callback SPP:
	{
		log_e("%s spp register failed\n", __func__);	// log para depuracao.

		return (false);   // finaliza indicando a falha.
	}

//..................................................

	if ( esp_spp_init(ESP_SPP_MODE_CB) != ESP_OK )   // se nao conseguir inicializar a Interface SPP:
	{
		log_e("%s spp init failed\n", __func__);   // log para depuracao.

		return (false);   // finaliza indicando a falha.
	}

//..................................................

	if ( BTC_RX_Queue == NULL )	// se o RX Queue nao foi instanciado:
	{
		log_e("%s Queue creation error\n", __func__);	// log para depuracao.

		return (false);   // finaliza indicando a falha.
	}

//..................................................

	esp_bt_dev_set_device_name( name );	// seta o nome deste Dispositivo Bluetooth.

//..................................................

	cod.major = 0b00001;	// seta as caracteristicas deste sevico Bluetooth.
	cod.minor = 0b000100;
	cod.service = 0b00000010110;

	if ( esp_bt_gap_set_cod( cod, ESP_BT_INIT_COD ) != ESP_OK )   // se nao conseguir setar:
	{
		log_e("%s set cod failed\n", __func__);   // log para depuracao.

		return (false);   // finaliza indicando a falha.
	}

//..................................................

	return (true);	// finaliza, indicando que o SPP foi inicializado com sucesso.
}
//***********************************************************************




//***********************************************************************
//	Finaliza e fecha o Sub-Sistema Bluetooth.
//
//	OBS.:
//	Apos a chamada a esta rotina, o Sub-Sistema Bluetooth so'
//	podera' ser reiniciado apos um ciclo de energia do ESP32,
//	ou seja, apos desligar e religar a alimentacao do mesmo.
//	Isto ocorre devido 'a forma como o Sub-Sistema Bluetooth
//	foi implementado em Firmware pela Espressif. Eventualmente
//	em liberacoes futuras da Espressif, esta limitacao podera'
//	nao existir.
//=======================================================================

bool BTC_Serial::BTC_SPP_stop ()
{
	if ( btStarted() )	// se o Bluetooth foi iniciado:
	{
		esp_bluedroid_disable();   // desabilita e para o BLUEDROID.
		esp_bluedroid_deinit();
		btStop();
	}

	BTC_SPP_client = 0;	// indica que nao ha' Client conectado.

	free( BTC_RX_Queue );	// libera o espaco usado pelo RX Queue.

	return (true);	// finaliza, indicando que "parou" com sucesso.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//		Implementacao da Interface da Classe.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	"Constructor" da Classe.
//=======================================================================

BTC_Serial::BTC_Serial ()
{
	Event = BTC_EVENT_none;   // reseta o indicador de Eventos.
}
//***********************************************************************




//***********************************************************************
//	"Destructor" da Classe.
//
//	OBS.:
//	Apos a chamada a este Metodo, o Sub-Sistema Bluetooth so'
//	podera' ser reiniciado apos um ciclo de energia do ESP32,
//	ou seja, apos desligar e religar a alimentacao do mesmo.
//	Isto ocorre devido 'a forma como o Sub-Sistema Bluetooth
//	foi implementado em Firmware pela Espressif. Eventualmente
//	em liberacoes futuras da Espressif, esta limitacao podera'
//	nao existir.
//=======================================================================

BTC_Serial::~BTC_Serial ()
{
	BTC_SPP_stop();   // paralisa a infra-estrutura Bluetooth no ESP32.
}
//***********************************************************************




//***********************************************************************
//	Inicia a Interface SPP, especificando o nome do Dispositivo
//	Bluetooth que sera' visto por outros Dispositivos.
//=======================================================================

bool	BTC_Serial::begin ( String device_name )
{
//--------------------------------------------------
bool Ok;
//--------------------------------------------------

	if ( device_name.length() == 0 )   // se nao especificou um nome:
	{
		device_name = "BTC_SPP";   // usa o nome default.
	}

	Ok = BTC_SPP_init( device_name.c_str() );   // tenta iniciar o SPP.

	return (Ok);	// finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Desconfigura a Interface SPP, permitindo assim uma posterior
//	reinicializacao.
//=======================================================================

bool	BTC_Serial::BTC_deinit ()
{
//--------------------------------------------------
esp_err_t err;
//--------------------------------------------------

	if ( BTC_SPP_client != 0 )   // se ha' um Cliente SPP conectado:
	{
		esp_spp_disconnect( BTC_SPP_client );	// desconecta esse Cliente.

		BTC_SPP_client = 0;	// indica que nao ha' Client conectado.
	}

	err = esp_spp_deinit();   // tenta desconfigurar a Interface SPP.

	return ( err == ESP_OK );   // finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Verifica se ha' um Cliente conectado via Interface SPP.
//=======================================================================

bool	BTC_Serial::hasClient ()
{
	return ( BTC_SPP_client != 0 );   // finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Le o numero "PIN" do Cliente atual conectado via Interface SPP.
//	O numero "PIN" e' sempre composto de 6 Bytes, e cada Dispositivo
//	Bluetooth tem um numero "PIN" unico, que e' sempre designado pelo
//	Fabricante do Dispositivo, e regulado pelo consorcio Bluetooth
//	Internacional (bluetooth.org):
//=======================================================================

bool	BTC_Serial::Client_PIN_get ( BTC_Client_PIN_type* Client_PIN_PTR )
{
//--------------------------------------------------
bool Ok = false;
uint8_t i;
//--------------------------------------------------

	if ( BTC_SPP_client != 0 )   // se ha' um Cliente conectado:
	{
		for ( i = 0; i < 6; i++ )   // le todos os 6 Bytes do "PIN".
		{
			(*Client_PIN_PTR) [i] = BTC_Client_PIN [i];
		}

		Ok = true;	// indica que leu o "PIN" com sucesso.
	}

	return (Ok);	// finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Informa o total de Bytes enviados pelo Cliente atual, via
//	Interface SPP.
//=======================================================================

int	BTC_Serial::available ()
{
//--------------------------------------------------
int tot = 0;
//--------------------------------------------------

	if ( BTC_RX_Queue != NULL )	// se o RX Queue e' valido:
	{
		if ( BTC_SPP_client != 0 )   // se ha' um Cliente conectado:
		{
			tot = uxQueueMessagesWaiting( BTC_RX_Queue );  // obtem o total recebido.
		}
	}

	return (tot);	// finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Le uma copia do proximo Byte enviado pelo Cliente via SPP.
//	Apenas uma copia ("amostra") e' obtida do RX Queue, e o Byte
//	ainda permanece no Queue para posterior leitura via Metodo
//	"read" (o qual efetivamente retirara' o Byte do RX Queue).
//
//	OBS.:
//	o valor retornado e' do tipo "int", permitindo assim informar
//	se nao foi possivel obter uma copia, atraves do retorno do
//	valor "-1" (ou seja "65535", em valor absoluto de 16 bits).
//=======================================================================

int	BTC_Serial::peek ()
{
//--------------------------------------------------
uint8_t c;
int val = -1;
//--------------------------------------------------

	if ( available() )   // se recebeu algum Byte:
	{
		if ( xQueuePeek( BTC_RX_Queue, &c, 0 ) )   // tenta ler uma copia:
		{
			val = c;   // se conseguiu ler, obtem esta copia do Byte.
		}
	}

	return (val);	// finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Le o proximo Byte enviado pelo Cliente atual, via SPP. Este
//	Metodo efetivamente retira um Byte do RX Queue, desde que
//	este tenha algum (deve ser usado o Metodo "available" antes,
//	a fim de se verificar se o Cliente enviou dados).
//=======================================================================

int	BTC_Serial::read ()
{
//--------------------------------------------------
uint8_t c;
int val = 0;
//--------------------------------------------------

	if ( available() )   // se recebeu algum Byte:
	{
		if ( xQueueReceive( BTC_RX_Queue, &c, 0 ) )   // tenta ler:
		{
			val = c;   // se conseguiu ler, obtem este Byte.
		}
	}

	return (val);	// finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	envia o Byte especificado, ao Cliente atual, via SPP. Se o
//	envio teve sucesso, a rotina retorna "1", do contrario ela
//	retorna "0".
//=======================================================================

size_t	BTC_Serial::write ( uint8_t c )
{
//--------------------------------------------------
uint8_t Buffer[1];
esp_err_t err;
size_t result = 0;
//--------------------------------------------------

	if ( BTC_SPP_client != 0 )   // se ha' um Cliente conectado:
	{
		Buffer[0] = c;   // copia o Byte para o Buffer de envio.

		err = esp_spp_write( BTC_SPP_client, 1, Buffer );   // envia pelo SPP.

		if  ( err == ESP_OK ) result = 1;   // verifica se nao ocorreu erro.
	}

	return ( result );   // finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	envia o Vetor de Bytes especificado, via SPP. Se o envio
//	teve sucesso, a rotina retorna o total de bytes enviado,
//	do contrario ela retorna "0".
//=======================================================================

size_t	BTC_Serial::write ( const uint8_t* Buffer, size_t size )
{
//--------------------------------------------------
esp_err_t err;
size_t result = 0;
//--------------------------------------------------

	if ( BTC_SPP_client != 0 )   // se ha' um Cliente conectado:
	{
		err = esp_spp_write( BTC_SPP_client, size, (uint8_t*) Buffer );   // envia Vetor pelo SPP.

		if  ( err == ESP_OK ) result = size;   // verifica se nao ocorreu erro.
	}

	return ( result );   // finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	Metodo mantido apenas pela exigencia da Classe "Stream", e
//	para compatibilidade com codigos mais antigos.
//	A rotina foi implementada nos moldes da LIB SPP Bluetooth
//	original (a IDF 1.0.0). Embora possa parecer estranho o uso do
//	"available" como referencia para "enviar" os bytes restantes,
//	pode haver uma explicacao simples: provavelmente foi utilizada
//	em testes de desenvolvimento, onde os bytes que eram recebidos,
//	tambem eram retornados a quem os enviou. Entao, isso seria o
//	motivo da rotina enviar os bytes que ainda estao no Queue de
//	recepcao, garantindo assim que quem os enviou nao fique em uma
//	espera "infinita" quando o proprio codigo que esta' executando
//	fecha a conexao SPP (pois e' comum em desenvolvimento, que nao
//	se implemente algum timeout).
//	Claro que desta forma, a rotina fica praticamente sem uma outra
//	utilidade mais interessante. E podera' provocar comportamentos
//	estranhos para quem nao conheca como a rotina trabalha (uma vez
//	que podera' enviar mais bytes que o esperado).
//=======================================================================

void	BTC_Serial::flush()
{
//--------------------------------------------------
int qsize;
//--------------------------------------------------

	if ( BTC_SPP_client != 0 )   // se ha' um Cliente conectado:
	{
		qsize = available();	// obtem o total restante no Queue de recepcao.

		uint8_t Buffer [qsize];   // prepara um Buffer com esse total.

		esp_spp_write( BTC_SPP_client, qsize, Buffer );   // envia pelo SPP.
	}
}
//***********************************************************************




//***********************************************************************
//	faz desconexao do Cliente atualmente conectado via SPP.
//	A utilidade deste Metodo, e' garantir que se possa reiniciar
//	uma conexao SPP com um novo "begin", apos os recursos de HW/FW
//	terem sido direcionados para outro padrao wireless (no atual
//	momento seria o WiFi, mas podera' ser qualquer outro que venha
//	a ser implementado).
//=======================================================================

bool	BTC_Serial::disconnect ()
{
//--------------------------------------------------
esp_err_t err;
//--------------------------------------------------

	if ( BTC_SPP_client != 0 )   // se ha' um Cliente conectado:
	{
		err = esp_spp_disconnect( BTC_SPP_client );   // desconecta o SPP.

		BTC_SPP_client = 0;   // registra que nao ha' Cliente conectado.
	}
	else err = ESP_FAIL;	// se nao ha' Cliente, indica erro.

	return ( err == ESP_OK );   // finaliza indicando o resultado.
}
//***********************************************************************




//***********************************************************************
//	equivalente ao Destructor da Classe (ver detalhes importantes na implementacao).
//
//	OBS.:
//	Apos a chamada a este Metodo, o Sub-Sistema Bluetooth so'
//	podera' ser reiniciado apos um ciclo de energia do ESP32,
//	ou seja, apos desligar e religar a alimentacao do mesmo.
//	Isto ocorre devido 'a forma como o Sub-Sistema Bluetooth
//	foi implementado em Firmware pela Espressif. Eventualmente
//	em liberacoes futuras da Espressif, esta limitacao podera'
//	nao existir.
//=======================================================================

void	BTC_Serial::end ()
{
	BTC_SPP_stop();
}
//***********************************************************************




#endif	// _new_BTC_SPP_rev_001_cpp_

