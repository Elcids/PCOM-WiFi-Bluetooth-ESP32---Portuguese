

#ifndef	_PCOM_WF_BTC_001_h_   // garante processamento unico.
#define	_PCOM_WF_BTC_001_h_


// **********************************************************************
// **********************************************************************
// **
// **	Descricao basica das funcionalidades:
// **
// **	Implementação de um Gerenciador para a Conexao Automatica de
// **	um Sistema baseado no ESP32 da Plataforma Arduino, em uma
// **	rede WiFi local ou em dispositivos Bluetooth (como Tablets,
// **	Smartphones, Computadores, etc), permitindo-se o controle
// **	deste Sistema atraves destas conexoes.
// **	O Gerenciador conecta-se automaticamente na conexao que esta'
// **	atualmente disponivel, seja WiFi ou Bluetooth. Se uma conexao
// **	e' perdida, entao o Gerenciador automaticamente procura se
// **	conectar na outra.
// **
// **	Para controle via Bluetooth, o dispositivo de conexao devera'
// **	usar Interface SPP (Serial Port Profile) via Bluetooth Classic.
// **	Para tal, o usuario pode criar seu proprio APP dedicado, ou
// **	usar qualquer APP de Terminal SPP (existem muitos, com os mais
// **	diversos recursos, por exemplo o "Serial Bluetooth Terminal" do
// **	desenvolvedor "Kai Morich", o qual utilizei nos testes deste
// **	Gerenciador). Ha' muitas possibilidades de controle, como o
// **	popular "Blink" e diversos outros semelhantes.
// **
// **	Para controle via WiFi local, pode-se utilizar uma Interface
// **	via Pagina HTML. Neste Gerenciador ha' recursos para facilitar
// **	tremendamente o gerenciamento de uma Interface HTML, inclusive
// **	utilizando-se quaisquer quantidades de paginas HTML, e de forma
// **	muito simples e eficiente. E pode-se tambem utilizar quaisquer
// **	outros Protocolos, sejam padroes ou dedicados.
// **
// **	No controle via Bluetooth Classic, foi criado um Mecanismo para
// **	a Autenticacao do Cliente via senha (pois a implementacao atual
// **	da Espressif nao usa senha de pareamento Bluetooth). E' exigida
// **	a Autenticacao de um Cliente uma unica vez, pois o Mecanismo
// **	salva na "EEPROM" do ESP32 a Lista de Clientes ja' autenticados.
// **	Nesta implementacao, o maximo de Clientes na Lista e' limitado
// **	a ate' 70 Clientes. Assim, o codigo atual sendo executado pelo
// **	ESP32 pode (a criterio do mesmo), permitir o acesso ao controle
// **	do Sistema, apenas quando um Cliente esta' autenticado.
// **
// **	No controle via WiFi local (ou mesmo via Internet, atraves de
// **	um "Port Foward"), a Autenticacao fica por conta do codigo atual
// **	sendo executado pelo ESP32, permitindo-se personalizar isto da
// **	forma desejada (onde provavelmente uma Pagina HTML solicitando
// **	uma Autenticacao com senha, seria uma das formas mais atrativas).
// **	Isto foi feito dessa forma, pois em rede WiFi local normalmente
// **	ja' existe Autenticacao atraves de senha. Entao isto da' maior
// **	flexibilidade para o usuario escolher a melhor forma que ele
// **	achar ser adequada para aumentar a seguranca do Sistema.
// **
// **	O Endereco IP no qual o ESP32 aparece, e' designado pela rede
// **	WiFi local, sendo exibido no Terminal do Arduino logo que o
// **	Sistema inicia.
// **	Este Endereco IP tambem e' acessivel a qualquer momento atraves
// **	da funcao "WiFi.localIP()" que e' tradicional no ESP32, e assim
// **	o usuario pode decidir a forma que ele considera a mais adequada
// **	para exibir o IP atual (por exemplo em um Display LCD no Sistema,
// **	o que pode ser feito neste ESP32 ou em um outro Arduino).
// **	Uma outra possibilidade muito conveniente, e' designar ao ESP32
// **	deste Sistema, um Endereco IP especifico, o que normalmente e'
// **	feito na pagina do Roteador da Rede WiFi local.
// **
// **	A Interface do Gerenciador (a "API"), e' bastante simples, e
// **	exige poucas declaracoes e chamadas de funcoes (atraves das quais
// **	pode-se tambem especificar senhas, timeouts diversos, resetar a
// **	Lista de Clientes Bluetooth, especificar o Modo de Comando para
// **	Autenticacao do Bluetooth, etc).
// **
// **	E' possivel tambem ligar-se o "Modo Debug", permitindo-se ver no
// **	Terminal do Arduino, as diversas ocorrencias no Gerenciador.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Definicao das Bibliotecas do ESP32 utilizadas neste Sistema:
//=======================================================================

#include "WiFi.h"   // Lib WiFi do ESP32.

//***********************************************************************




//***********************************************************************
//	Implementacoes exclusivamente desenvolvidas para este Sistema:
//=======================================================================

#include "SYS_basics\Dynamic_Debug_001.h"   // utiliza o "Debug Dinamico".

#include "SYS_basics\SYS_types_001.h"  // definicoes auxiliares para este Sistema.

#include "new_BTC_SPP\new_BTC_SPP_rev_001.h"   // Implementacao da Interface SPP.

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//		Modelo basico para uso no Codigo do Arduino.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Especificando a Rede WiFi:
//
//	Modelo para especificar a Conexao WiFi utilizada no Sistema.
//	Defina o nome, senha, e Porta, conforme a rede WiFi utilizada:
//
//	- o nome da Rede WiFi, e' a Rede na qual o ESP32 se conectara'
//	para comunicacao com um Cliente WiFi.
//
//	- a senha da Rede WiFi, e' a senha para o ESP32 se conectar na
//	Rede especificada.
//
//	- o numero da Porta, e' a Porta TCP/IP usada para comunicacao
//	com o WiFi Server instanciado neste Sistema.
//
//=======================================================================
//
// WiFi_PCOM_info   dados_WiFi =
// {
//	"nome_WiFi",    // nome da Rede WiFi.
//
//	"senha_WiFi",   // senha da Rede WiFi.
//
//	80,    // Porta para o WiFi Server.
// };
//
//***********************************************************************




//***********************************************************************
//	Especificando o Dispositivo Bluetooth:
//
//	Modelo para especificar o dispositivo Bluetooth implementado
//	neste Sistema.
//	Defina o nome e senha, conforme desejado:
//
//	- o nome do dispositivo Bluetooth, e' o nome que aparecera' na
//	busca de dispositivos Bluetooth para pareamento em Smartphones,
//	Tablets, e Computadores.
//
//	- a senha, e' a que sera' requisitada a um Cliente Bluetooth,
//	para este Cliente se Autenticar neste Sistema.
//
//=======================================================================
//
// BTC_PCOM_info   dados_Bluetooth =
// {
//	"nome_Bluetooth",   // nome deste dispositivo Bluetooth.
//
//	"senha_Bluetooth",  // senha para Autenticacao neste dispositivo Bluetooth.
// };
//
//***********************************************************************




//***********************************************************************
//	Na funcao "setup()" do Arduino:
//
//	Modelo basico para inicializar o PCOM WiFi/Bluetooth na funcao
//	"setup()" do Arduino (executar na ordem mostrada):
//=======================================================================
//
// void	setup ()
// {
//	outras inicializacoes no setup:
//	....
//	....
// - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//
// - especifique se o "modo Debug" estara' desligado ou ligado:
//
//	desliga_DEBUG();  // desliga o modo Debug.
//	liga_DEBUG();   // liga o modo Debug.
//
// - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//
// - configure o PCOM WiFi e o PCOM Bluetooth:
//
//	define_parametros_PCOM_WiFi( &dados_WiFi );   // configura o PCOM WiFi.
//
//	define_parametros_PCOM_Bluetooth( &dados_Bluetooth );  // configura o PCOM Bluetooth.
//
// - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//
// - especifique um dos Modos de Comando para Autenticacao do PCOM Bluetooth:
//
//	define_Modo_Comando_PCOM_Bluetooth( BT_CMD_simples );  // usa Modo de Comando "simples" na Autenticacao Bluetooth.
//	define_Modo_Comando_PCOM_Bluetooth( BT_CMD_texto );   // usa Modo de Comando "texto" na Autenticacao Bluetooth.
//
// - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//
//	outras inicializacoes no setup:
//	....
//	....
// }
//
//***********************************************************************




//***********************************************************************
//	Na funcao "loop()" do Arduino:
//
//	Modelo basico para o gerenciamento do PCOM WiFi/Bluetooth na
//	funcao "loop()" do Arduino (executar na ordem mostrada).
//
//	Atencao:
//	Dentro do "loop()", evite o uso da funcao "delay" do Arduino,
//	para nao bloquear o gerenciamento do PCOM WiFi/Bluetooth.
//=======================================================================
//
// void loop()
// {
//	WiFi_Bluetooth_PCOM_Manager();  // gerencia PCOM WiFi/Bluetooth.
//
// - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//
//	outros processos no loop:
//	....
//	....
// }
//
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Definicao de tipos e recursos basicos da Interface (API) do
//	PCOM WiFi/Bluetooth.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao da estrutura para se especificar os principais
//	Parametros para o setup do PCOM WiFi:
//=======================================================================

struct	WiFi_info    // parametros para setup do PCOM WiFi:
{
	String nome_WiFi;    // nome da Rede WiFi.

	String senha_WiFi;   // senha da Rede WiFi.

	unsigned short	server_PORT;   // Porta TCP/IP para o WiFi Server.
};

//-----------------------------------------------------------------------

typedef	struct WiFi_info   WiFi_PCOM_info;  // tipo para o "WiFi_info".

//***********************************************************************




//***********************************************************************
//	Definicao da estrutura para se especificar os principais
//	Parametros para o setup do PCOM Bluetooth:
//=======================================================================

struct	BTC_info    // parametros para setup do PCOM Bluetooth:
{
	String nome_Bluetooth;   // nome do "Bluetooth Device".

	String senha_Bluetooth;   // senha para Autenticacao no Bluetooth.
};

//-----------------------------------------------------------------------

typedef	struct BTC_info   BTC_PCOM_info;  // tipo para o "BTC_info".

//***********************************************************************




//***********************************************************************
//	Definicoes relacionadas ao Modo de Comando utilizado para o
//	envio/recebimento de comandos atraves do PCOM Bluetooth, seja
//	para o processo de Autenticaco, seja para outros processos de
//	controle interno do PCOM Bluetooth.
//
//	Nesta implementacao, dois modos estao disponiveis:
//
//	1 = Modo Simples: comandos se iniciam com '#' e sao constituidos
//	por sequencias simples em ASCII. Os comandos sempre terminam com
//	a sequencia "Carriage Return" e "New Line", ou seja, os caracteres
//	nao-imprimiveis 0x0D e 0x0A, que na linguagem C sao tambem chamados
//	de '\r' e '\n'. O modo simples e' indicado quando os comandos serao
//	interpretados por outro programa ou uma maquina similar, pois este
//	formato simplifica o processo de decodificacao.
//	Exemplo: #TA , significa "Timeout de Autenticacao".
//
//	2 = Modo Texto: comandos se iniciam com '$' e sao constituidos por
//	palavras/texto "legiveis" em ACII. Os comandos sempre terminam com
//	a sequencia "Carriage Return" e "New Line", ou seja, os caracteres
//	nao-imprimiveis 0x0D e 0x0A, que na linguagem C sao tambem chamados
//	de '\r' e '\n'. O modo Texto e' indicado quando os comandos serao
//	interpretados por pessoas, ou seja, quando os caracteres do comando
//	sao exibidos em algo semelhante a uma caixa de dialogo ou Terminal
//	de Texto.
//	Exemplo: $ terminou tempo!!! , indicando Timeout de Autenticacao.
//
//=======================================================================

enum	// opcoes para o Modo de Comando via PCOM BT:
{
	BT_CMD_reserv,  // opcao "reservada" (para nao usar o "0" do "enum").

	BT_CMD_simples,   // opcao "modo comando simples" do PCOM Bluetooth.

	BT_CMD_texto,   // opcao "modo comando texto" do PCOM Bluetooth.
};
//***********************************************************************




//***********************************************************************
//	Definicao de um "tipo Ponteiro" para uma funcao que trata uma
//	requisicao de um Cliente WiFi. A funcao pode interpretar os
//	comandos recebidos na requisicao, e enviar ou atualizar Paginas
//	HTML conforme necessario. O Cliente pode ser um Navegador em um
//	Computador, Tablet, Smartphone, ou qualquer outro dispositivo
//	com um protocolo dedicado (encapsulado no TCP/IP).
//	A funcao sera' chamada atraves de um mecanismo semelhante a um
//	"callback", quando uma requisicao e' enviada pelo Cliente WiFi.
//
//	Parametros:
//	- client_PTR = Ponteiro para o Cliente WiFi.
//	- string_PTR = Ponteiro para a String enviada pelo Cliente WiFi.
//=======================================================================

typedef void (*HTML_Processor) ( WiFiClient* client_PTR, String* string_PTR );

//***********************************************************************




//***********************************************************************
//	Faz o cadenciamento da execucao das Maquinas de Estados que
//	gerenciam o PCOM WiFi/Bluetooth.
//=======================================================================

void	WiFi_Bluetooth_PCOM_Manager ();  // gerencia o PCOM WiFi/Bluetooth.

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//		Recursos da Interface (API) do PCOM WiFi.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Funcao para alterar o status atual de permissao de conexao
//	via PCOM WiFi.
//	Se a conexao nao e' permitida, entao o PCOM WiFi nao sera'
//	utilizado para estabelecer uma conexao no Sistema, e neste
//	caso se o PCOM WiFi estiver atualmente conectado entao ele
//	sera' desconectado.
//	Se a conexao e' permitida, o PCOM WiFi podera' ser utilizado
//	para estabelecer uma conexao no Sistema. Neste caso, tambem
//	sera' rotineiramente verificado se foi enviado algum comando
//	via Debug para controle do PCOM WiFi.
//	A permissao pode ser alterada a qualquer momento, ou seja, e'
//	do tipo "on the fly".
//=======================================================================

void	controla_Permissao_PCOM_WiFi ( bool permite );

//***********************************************************************




//***********************************************************************
//	Especifica os parametros principais para configuracao do
//	PCOM WiFi. Estes parametros sao especificados atraves de
//	uma estrutura "WiFi_PCOM_info", a qual contem o Nome e a
//	Senha da Rede WiFi onde o Sistema se conectara', alem do
//	numero da Porta TCP/IP para acesso ao instanciamento do
//	WiFi Server usado no PCOM WiFi.
//=======================================================================

void	define_parametros_PCOM_WiFi ( WiFi_PCOM_info* WiFi_info_PTR );

//***********************************************************************




//***********************************************************************
//	Especifica o timeout para se esperar a conexao da rede WiFi.
//	Para facilitar o uso, o timeout e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_Timeout_conexao_WiFi ( unsigned short segundos );

//***********************************************************************




//***********************************************************************
//	Verifica se o PCOM WiFi esta' disponivel para comunicacao.
//	O codigo atualmente em execucao no Arduino, deve verificar
//	se o PCOM WiFi esta' disponivel antes de qualquer processo
//	de comunicacao com um Cliente WiFi. A verificacao deve ser
//	periodica, uma vez que a Rede WiFi utilizada como meio de
//	comunicacao, pode nao estar mais disponivel em um momento
//	qualquer (por exemplo, na ausencia de energia).
//
//	Obs.:
//	Esta disponibilidade, NAO indica que um Cliente WiFi fez uma
//	Autenticacao neste Sistema. Assim, qualquer Autenticacao do
//	Cliente, deve ser implementada no codigo do Arduino, o que
//	permite uma grande flexibilidade no nivel de seguranca para
//	um controle via WiFi.
//=======================================================================

bool	WiFi_disponivel ();   // informa se o WiFi esta' disponivel.

//***********************************************************************




//***********************************************************************
//	Obtem um eventual Cliente que esteja tambem conectado na
//	mesma Rede WiFi na qual este Sistema esta' conectado. Se
//	houver um Cliente WiFi conectado, este Cliente pode entao
//	se comunicar com o codigo do Arduino atualmente em execucao.
//	A comunicacao pode ser por Paginas HTML (ou seja, protocolo
//	"http"), ou qualquer outro protocolo padrao ou dedicado.
//	Qualquer Autenticacao do Cliente, deve ser implementada no
//	codigo do Arduino, permitindo assim grande flexibilidade no
//	nivel de seguranca para um controle via WiFi.
//
//	Obs.:
//	O Cliente WiFi, e' da mesma Classe "WiFi" da implementacao
//	do ESP32 para a plataforma Arduino, e portanto tem as mesmas
//	funcionalidades de um Cliente da Classe "WiFi", incluindo as
//	funcionalidades da Classe "Stream" e da Classe "Print".
//=======================================================================

WiFiClient   obtem_Cliente_WiFi ();   // retorna Cliente WiFi.

//***********************************************************************




//***********************************************************************
//	Seta o timeout para atendimento a um Cliente HTML. O periodo
//	e' especificado em unidades de segundos, para facilidade de
//	utilizacao da rotina. O timeout pode ser alterado a qualquer
//	momento ("on the fly").
//
//	Parametros:
//	- segundos = periodo do timeout, em segundos.
//=======================================================================

void	define_timeout_HTML_WiFi ( unsigned short segundos );

//***********************************************************************




//***********************************************************************
//	Gerencia Paginas HTML para um Cliente conectado via WiFi.
//	Essencialmente, a rotina gerencia a recepcao de requisicoes
//	do Cliente (se um estiver conectado). Quando uma requisicao
//	e' completada, a rotina chama a funcao que ira' processar a
//	requisicao do Cliente, passando para esta funcao a string que
//	corresponde a requisicao (esta string normalmente e' enviada
//	pelo navegador utilizado pelo Cliente). A funcao a ser chamada
//	(em um formato semelhante a um "callback"), e' passada para
//	esta rotina por quem chamou a mesma, juntamente com o Cliente
//	atual. Um timeout tambem esta' implementado, para o caso do
//	Cliente nao concluir a requisicao iniciada. Quando o timeout
//	ocorre, a requisicao e' descartada e a conexao com o Cliente
//	e' fechada, mas podera' ser reaberta se o Cliente reconectar.
//	Na saida, a rotina informa se alguma requisicao foi recebida.
//
//	Parametros:
//	- client_PTR = Ponteiro para o Cliente WiFi.
//	- HTML_Proc = funcao que ira' processar a Pagina HTML.
//
//	Saida:
//	- true = a rotina recebeu uma requisicao do Cliente WiFi.
//	- false = a rotina NAO recebeu uma requisicao do Cliente WiFi.
//=======================================================================

bool	WiFi_HTML_Client_Manager ( WiFiClient* client_PTR, HTML_Processor HTML_Proc );

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//		Recursos da Interface (API) do PCOM Bluetooth.
//
//	Aqui nao esta' listada a Interface para o SPP Bluetooth, ja'
//	que esta Interface e' baseada no SPP original do ESP32 para
//	a Plataforma Arduino (e portanto tem as mesmas funcionalidades
//	da Classe "Stream" e Classe "Print" do Arduino). A Interface
//	SPP implementada, tem algumas poucas novas funcionalidades, as
//	quais serao exploradas em exemplos para demonstrar seu uso.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Funcao para alterar o status atual de permissao de conexao
//	via PCOM WiFi.
//	Se a conexao nao e' permitida, entao o PCOM Bluetooth nao sera'
//	utilizado para estabelecer uma conexao no Sistema, e neste caso
//	se o PCOM Bluetooth estiver atualmente conectado entao ele sera'
//	desconectado.
//	Se a conexao e' permitida, o PCOM Bluetooth podera' ser utilizado
//	para estabelecer uma conexao no Sistema. Neste caso, tambem sera'
//	rotineiramente verificado se foi enviado algum comando via Debug
//	para controle do PCOM Bluetooth.
//	A permissao pode ser alterada a qualquer momento, ou seja, e'
//	do tipo "on the fly".
//=======================================================================

void	controla_Permissao_PCOM_Bluetooth ( bool permite );

//***********************************************************************




//***********************************************************************
//	Especifica os parametros principais para configuracao do
//	PCOM Bluetooth. Estes parametros sao especificados atraves
//	de uma estrutura "BTC_PCOM_info", a qual contem o Nome do
//	"Bluetooth Device" (nome do Dispositivo Bluetooth para este
//	Sistema) e a Senha para Autenticacao de Clientes Bluetooth.
//	neste Sistema.
//=======================================================================

void	define_parametros_PCOM_Bluetooth ( BTC_PCOM_info* BTC_info_PTR );

//***********************************************************************




//***********************************************************************
//	Especifica o timeout para espera da Configuracao Bluetooth e
//	da conexao de um Cliente Bluetooth.
//	Para facilitar o uso, o timeout e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_Timeout_conexao_Bluetooth ( unsigned short segundos );

//***********************************************************************




//***********************************************************************
//	Especifica o Modo de Comando atual utilizado no envio/recebimento
//	de comandos no PCOM Bluetooth, para o processo de Autenticaco de
//	um Cliente e para controles internos do PCOM Bluetooth.
//	Fora deste escopo, o codigo do Arduino esta' livre para utilizar
//	qualquer outro Modo de Comando que ele desejar.
//
//	Nesta implementacao, dois modos estao disponiveis:
//
//	1 = Modo Simples: comandos se iniciam com '#' e sao constituidos
//	por sequencias simples em ASCII. Os comandos sempre terminam com
//	a sequencia "Carriage Return" e "New Line", ou seja, os caracteres
//	nao-imprimiveis 0x0D e 0x0A, que na linguagem C sao tambem chamados
//	de '\r' e '\n'. O modo simples e' indicado quando os comandos serao
//	interpretados por outro programa ou uma maquina similar, pois este
//	formato simplifica o processo de decodificacao.
//	Exemplo: #TA , significa "Timeout de Autenticacao".
//
//	2 = Modo Texto: comandos se iniciam com '$' e sao constituidos por
//	palavras/texto "legiveis" em ACII. Os comandos sempre terminam com
//	a sequencia "Carriage Return" e "New Line", ou seja, os caracteres
//	nao-imprimiveis 0x0D e 0x0A, que na linguagem C sao tambem chamados
//	de '\r' e '\n'. O modo Texto e' indicado quando os comandos serao
//	interpretados por pessoas, ou seja, quando os caracteres do comando
//	sao exibidos em algo semelhante a uma caixa de dialogo ou Terminal
//	de Texto.
//	Exemplo: $ terminou tempo!!! , indicando Timeout de Autenticacao.
//
//	Para uma Lista dos Comandos implementados e respectiva descricao
//	destes comandos, consultar documentacao especifica.
//	Na implementacao atual, os comandos existentes estao relacionados
//	ao processo de Autenticaco de um Cliente Bluetooth.
//
//	Embora o Modo de Comando possa ser alterado a qualquer momento
//	("on the fly"), em geral isso e' feito apenas na inicializacao
//	do Sistema.
//=======================================================================

void	define_Modo_Comando_PCOM_Bluetooth ( byte modo );

//***********************************************************************




//***********************************************************************
//	Especifica o numero maximo de tentativas de insercao da
//	senha de Autenticacao de um Cliente Bluetooth, quando a
//	senha inserida e' invalida.
//	Apos este numero de tentativas, o Cliente tera' que esperar
//	o tempo definido pelo "intervalo de Autenticacao" antes da
//	proxima tentativa de Autenticacao.
//=======================================================================

void	define_tentativas_Senha_Bluetooth ( byte tentativas );

//***********************************************************************




//***********************************************************************
//	Especifica o timeout para a insercao da senha de Autenticacao
//	de um Cliente Bluetooth. Este timeout se refere ao numero
//	maximo de tentativas. Exemplo: se foi especificado um maximo
//	de 3 tentativas, o Cliente tera' o tempo de timeout para fazer
//	estas 3 tentativas. O Sistema garante um minimo de 15 segundos
//	para cada tentativa, de forma que se o valor de timeout for
//	incoerente com isso, este timeout sera' recalculado para que
//	fique coerente com esta regra.
//	Este timeout e' chamado de "timeout de Autenticacao".
//	Para facilitar o uso, o timeout e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_Timeout_Autenticar_Bluetooth ( unsigned short segundos );

//***********************************************************************




//***********************************************************************
//	Especifica o intervalo de tempo ate' a proxima tentativa de
//	Autenticacao de um Cliente Bluetooth, apos este Cliente ter
//	feito o maximo de tentativas atualmente definido. Logo, se um
//	Cliente fez todas as tentativas inserindo senhas incorretas,
//	ele tera' que esperar este intervalo de tempo ate' que possa
//	fazer novas tentativas. Isto tambem ocorre se o Cliente se
//	desconectar durante o processo de Autenticacao.
//	Este intervalo e' chamado de "intervalo de Autenticacao".
//	Para facilitar o uso, o intervalo e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_intervalo_Autenticar_Bluetooth ( unsigned short segundos );

//***********************************************************************




//***********************************************************************
//	Reseta a Lista de Clientes Bluetooth autenticados neste
//	Sistema. Na saida, a funcao informe se a Lista foi resetada.
//
//	Atencao: se o PCOM ativo for o PCOM Bluetooth, entao a Lista
//	nao sera' resetada.
//=======================================================================

bool	reseta_Lista_Autenticar_Bluetooth ();

//***********************************************************************




//***********************************************************************
//	Verifica se o PCOM Bluetooth esta' disponivel para comunicacao.
//	O codigo atualmente em execucao no Arduino, deve verificar se
//	o PCOM Bluetooth esta' disponivel antes de qualquer processo de
//	comunicacao com um Cliente Bluetooth. Esta verificacao deve ser
//	periodica, uma vez que a Rede Bluetooth utilizada como meio de
//	comunicacao, pode nao estar mais disponivel em qualquer momento,
//	ou o Cliente Bluetooth pode ter se desconectado repentinamente.
//
//	Obs.:
//	Esta disponibilidade INDICA que o Cliente passou pelo processo
//	de Autenticacao Bluetooth (atraves de senha de Autenticacao).
//=======================================================================

bool	Bluetooth_disponivel ();

//***********************************************************************




//***********************************************************************
//	Obtem Ponteiro para a Interface SPP Bluetooth do Sistema.
//	Atraves deste Ponteiro o codigo do Arduino atualmente em
//	execucao, pode se comunicar com um Cliente Bluetooth via
//	Interface SPP instanciada no Sistema (e' possivel apenas
//	uma unica instancia SPP).
//	A comunicacao nao tem um protocolo padrao definido, assim
//	o usuario pode implementar essa comunicacao da forma que
//	considerar mais adequada para a intencao de uso.
//	Mas para o Cliente poder acessar o controle deste Sistema,
//	ele deve antes ter passado pelo processo de Autenticacao
//	Bluetooth, o que acrescenta um nivel de seguranca atraves
//	de uma senha de Autenticacao.
//
//	Obs.:
//	Esta Interface SPP Bluetooth, tem as mesmas funcionalidades
//	da Classe "BluetoothSerial" da implementacao do ESP32 para
//	a plataforma Arduino, e portanto tem as funcionalidades da
//	Classe "Stream" e da Classe "Print".
//=======================================================================

BLUE_Device_PTR   obtem_SPP_Bluetooth_PTR ();  // retorna Ponteiro para o SPP Bluetooth.

//***********************************************************************



#endif	// _PCOM_WF_BTC_001_h_

