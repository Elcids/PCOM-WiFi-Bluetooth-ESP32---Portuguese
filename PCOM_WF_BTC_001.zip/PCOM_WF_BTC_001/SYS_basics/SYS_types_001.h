

#ifndef	_SYS_types_h_   // garante processamento unico.
#define	_SYS_types_h_


// **********************************************************************
// **********************************************************************
// **
// **	Definicao de tipos e Macros para simplificar a codificacao
// **	de um programa para a Plataforma Arduino.
// **
// **	As definicoes podem referenciadas pelo #include do arquivo,
// **	ou copiadas diretamente para o codigo fonte, uma vez que
// **	esta assegurado o "processamento unico" mesmo para trechos
// **	individuais.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Definicao de tipos para facilitar a codificacao de programas:
//=======================================================================

#ifndef	_nomes_tipos_	// garante processamento unico.
#define	_nomes_tipos_

//_______________________________________________________________________

typedef	unsigned int	uint;	// inteiro nao sinalizado (tamanho varia conforme plataforma).

//-----------------------------------------------------------------------

typedef	unsigned char	BYTE;	// inteiro de 8 bits nao sinalizado (0 a 255).
typedef	unsigned short	WORD;	// inteiro de 16 bits nao sinalizado (0 a 65535).
typedef	unsigned long	DWORD;	// inteiro de 32 bits nao sinalizado (0 a 4294967295).

typedef	signed char	sBYTE;	// inteiro de 8 bits sinalizado (-128 a +127).
typedef	signed short	sWORD;	// inteiro de 16 bits sinalizado (-32768 a +32767).
typedef	signed long	sDWORD;	// inteiro de 32 bits sinalizado (-2147483648 a +2147483647).

//-----------------------------------------------------------------------

typedef	BYTE*	BYTE_PTR;   // tipo Ponteiro para acesso a Bytes.

typedef	void**	PTR_of_PTR;   // para apontar um Ponteiro Generico.

//_______________________________________________________________________

#endif	// _nomes_tipos_

//***********************************************************************




//***********************************************************************
//	Definicao de tipos/funcoes para acesso a Memoria de Programa.
//	As definicoes sao para Processadores AVR, e poderao funcionar
//	para outros Processadores, desde que definidas ou emuladas na
//	implementacao da plataforma Arduino para estes Processadores.
//=======================================================================

#ifndef	_ROM_types_h_	// garante processamento unico.
#define	_ROM_types_h_

//_______________________________________________________________________

#ifdef __AVR__
#include <avr/pgmspace.h>   // para acesso à FLASH da CPU AVR.
#endif

#ifdef ESP8266
#include <pgmspace.h>   // para acesso à FLASH do ESP8266.
#endif

#ifdef ESP32
#include <pgmspace.h>   // para acesso à FLASH do ESP32.
#endif

//-----------------------------------------------------------------------

#define	ROM_set	const PROGMEM	// para definicao de dados na Flash.

//-----------------------------------------------------------------------

#define ROM_get8(var)	pgm_read_byte_near(var)	// para ler um Byte armazenado na Flash.

#define ROM_get16(var)	pgm_read_word_near(var)	// para ler uma Word armazenada na Flash.

#define ROM_PTR_get(var) pgm_read_ptr_near(var)	// para ler um Ponteiro armazenado na Flash.

//_______________________________________________________________________

#endif	// _ROM_types_h_

//***********************************************************************




#ifndef	_TAB_bits_	// garante processamento unico.
#define	_TAB_bits_

//_______________________________________________________________________


//***********************************************************************
//	Definicao de padroes de bit, para facilitar a codificacao de
//	Programas, em acessos aos respectivos bits, de forma individual
//	ou em conjunto (via operador "|"):
//=======================================================================

#define	BIT_0	0x01	// padrao binario correspondente ao "bit 0".
#define	BIT_1	0x02	// padrao binario correspondente ao "bit 1".
#define	BIT_2	0x04	// padrao binario correspondente ao "bit 2".
#define	BIT_3	0x08	// padrao binario correspondente ao "bit 3".
#define	BIT_4	0x10	// padrao binario correspondente ao "bit 4".
#define	BIT_5	0x20	// padrao binario correspondente ao "bit 5".
#define	BIT_6	0x40	// padrao binario correspondente ao "bit 6".
#define	BIT_7	0x80	// padrao binario correspondente ao "bit 7".

#define	BIT_8	0x0100	// padrao binario correspondente ao "bit 8".
#define	BIT_9	0x0200	// padrao binario correspondente ao "bit 9".
#define	BIT_10	0x0400	// padrao binario correspondente ao "bit 10".
#define	BIT_11	0x0800	// padrao binario correspondente ao "bit 11".
#define	BIT_12	0x1000	// padrao binario correspondente ao "bit 12".
#define	BIT_13	0x2000	// padrao binario correspondente ao "bit 13".
#define	BIT_14	0x4000	// padrao binario correspondente ao "bit 14".
#define	BIT_15	0x8000	// padrao binario correspondente ao "bit 15".

//***********************************************************************




//***********************************************************************
//	Retorna o padrao de bits para o bit especificado na faixa de
//	8 bits, ou seja, bits 0 a 7.
//=======================================================================

BYTE	bit8_Pattern_GET ( BYTE bit_N );  // retorna o padrao de bits requisitado.

//***********************************************************************




//***********************************************************************
//	Retorna o padrao de bits para o bit especificado na faixa de
//	16 bits, ou seja, bits 0 a 15.
//=======================================================================

WORD	bit16_Pattern_GET ( BYTE bit_N );  // retorna o padrao de bits requisitado.

//***********************************************************************


//_______________________________________________________________________

#endif	// _TAB_bits_




//***********************************************************************
//	Macro para simplificar a definicao de periodos de tempo em
//	unidades de segundos (o periodo pode ser fracionario).
//	Assim, esta Macro apenas converte o valor para mili-segundos,
//	para que o resultado desta conversao possa ser utilizado em
//	comparacoes usando o "millis" do Arduino.
//
//	Obs.:
//	Devido ao tamanho de 32 bits do "unsigned long", o maximo
//	valor permitido e' proximo de 50 dias (assim como o proprio
//	valor retornado pelo "millis" do Arduino).
//=======================================================================

#ifndef	_DEF_SEGUNDOS_	// garante processamento unico.
#define	_DEF_SEGUNDOS_

#define	em_segundos(valor)   (unsigned long) ( (float) valor * 1000 )

#endif	// _DEF_SEGUNDOS_

//***********************************************************************




//***********************************************************************
//	Macro para simplificar a definicao de periodos de tempo em
//	unidades de minutos (o periodo pode ser fracionario).
//	A Macro converte o periodo para mili-segundos, resultando em
//	um tipo "unsigned long" e possibilitando que este resultado
//	seja utilizado em comparacoes usando o "millis" do Arduino.
//
//	Obs.:
//	Devido ao tamanho de 32 bits do "unsigned long", o maximo
//	valor permitido e' proximo de 50 dias (assim como o proprio
//	valor retornado pelo "millis" do Arduino).
//=======================================================================

#ifndef	_DEF_MINUTOS_	// garante processamento unico.
#define	_DEF_MINUTOS_

#define	em_minutos(valor)   (unsigned long) ( (float) valor * 60000 )

#endif	// _DEF_MINUTOS_

//***********************************************************************




//***********************************************************************
//	Macro para simplificar a definicao de periodos de tempo em
//	unidades de horas (o periodo pode ser fracionario).
//	A Macro converte o periodo para mili-segundos, resultando em
//	um tipo "unsigned long" e possibilitando que este resultado
//	seja utilizado em comparacoes usando o "millis" do Arduino.
//
//	Obs.:
//	Devido ao tamanho de 32 bits do "unsigned long", o maximo
//	valor permitido e' proximo de 50 dias (assim como o proprio
//	valor retornado pelo "millis" do Arduino).
//=======================================================================

#ifndef	_DEF_HORAS_	// garante processamento unico.
#define	_DEF_HORAS_

#define	em_horas(valor)   (unsigned long) ( (float) valor * 3600000 )

#endif	// _DEF_HORAS_

//***********************************************************************




//***********************************************************************
//	Macro para simplificar a definicao de periodos de tempo em
//	unidades de dias (o periodo pode ser fracionario).
//	A Macro converte o periodo para mili-segundos, resultando em
//	um tipo "unsigned long" e possibilitando que este resultado
//	seja utilizado em comparacoes usando o "millis" do Arduino.
//
//	Obs.:
//	Devido ao tamanho de 32 bits do "unsigned long", o maximo
//	valor permitido e' proximo de 50 dias (assim como o proprio
//	valor retornado pelo "millis" do Arduino).
//=======================================================================

#ifndef	_DEF_DIAS_	// garante processamento unico.
#define	_DEF_DIAS_

#define	em_dias(valor)   (unsigned long) ( (float) valor * 86400000 )

#endif	// _DEF_DIAS_

//***********************************************************************



#endif	// _SYS_types_h_

