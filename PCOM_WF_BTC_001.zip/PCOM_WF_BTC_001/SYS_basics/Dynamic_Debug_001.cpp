

#ifndef	_Dynamic_Debug_cpp_	// garante processamento unico.
#define	_Dynamic_Debug_cpp_


// **********************************************************************
// **********************************************************************
// **
// **	Definicoes para utilizacao do "Debug Dinamico" em um codigo
// **	para a Plataforma Arduino.
// **
// **	Descricao basica:
// **
// **	O "Debug Dinamico" permite que se ligue ou se desligue o Debug
// **	em qualquer ponto do codigo e a qualquer momento, o que portanto
// **	o torna muito mais versatil que o "Debug Estatico".
// **
// **	Alem disso, o "Debug Dinamico" se usado em uma Biblioteca que
// **	seja tradicionalmente formatada para a Linguagem C++, fara' com
// **	essa Biblioteca siga o controle do Debug determinado pelo codigo
// **	codigo principal (o arquivo ".ino").
// **	Isto ocorre porque no "Debug Dinamico", o controle ON/OFF do
// **	Debug nao depende das etapas de processamento do Compilador.
// **	Esta caracteristica bastante desejavel, nao e' possivel no
// **	"Debug Estatico".
// **
// **	No "Debug Dinamico", o codigo referente ao Debug sera' sempre
// **	incluido na Compilacao, e portanto ocupara' espaco na Memoria
// **	de Programa do Arduino.
// **
// **	Alem do ON/OFF dinamico do Debug, esta' implementada uma tecnica
// **	simples de save/restore do status atual do Debug. Isto permite
// **	por exemplo, salvar o status atual em trecho do codigo que se
// **	deseje ligar o Debug, e apos a execucao deste trecho se restaura
// **	o status do Debug anterior a este trecho, o que da' uma maior
// **	flexibilidade na utilizacao do Debug. Nao foi implementado algum
// **	tipo de encadeamento, pois isto necessitarira de um Queue para
// **	salvar e restaurar status encadeados dentro de funcoes. Assim o
// **	save/restore possui apenas um nivel de utilizacao, o que atende
// **	certamente 99.9% das necessidades, e poupa a memoria do Arduino
// **	(neste caso seria a RAM, muito mais critico).
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Arquivos de include utilizados:
//=======================================================================

#include "Dynamic_Debug_001.h"   // header com definicoes e prototipos.

//***********************************************************************




//***********************************************************************
//	Variavel para o estado ON/OFF do "Debug Dinamico", indicando
//	se o Debug esta' ou nao ligado em um determinado momento:
//=======================================================================

bool	SYS_DEBUG_state = false;   // estado ON/OFF atual do Debug.

//***********************************************************************




//***********************************************************************
//	Variavel para o backup do status ON/OFF do "Debug Dinamico",
//	para uso no mecanismo "save & restore" do Debug.
//=======================================================================

bool	SYS_DEBUG_backup = false;   // backup do status ON/OFF do Debug.

//***********************************************************************




//***********************************************************************
//	Informa se o Debug esta' atualmente ligado ou desligado. Este
//	status pode ser obtido "on the fly".
//=======================================================================

bool	SYS_DEBUG_state_GET ()
{
	return ( SYS_DEBUG_state );  // informa o estado ON/OFF atual do Debug.
}
//***********************************************************************




//***********************************************************************
//	Desliga o "Debug Dinamico". Isto pode ser feito "on the fly".
//=======================================================================

void	desliga_DEBUG ()
{
	SYS_DEBUG_state = false;   // desliga o "Debug Dinamico".
}
//***********************************************************************




//***********************************************************************
//	Liga o "Debug Dinamico". Isto pode ser feito "on the fly".
//=======================================================================

void	liga_DEBUG ()
{
	SYS_DEBUG_state = true;   // liga o "Debug Dinamico".
}
//***********************************************************************




//***********************************************************************
//	Faz o "save" para implementar o mecanismo "save & restore" do
//	"Debug Dinamico".
//	O mecanismo nao pode ser encadeado, ou seja, apos o "save" ter
//	sido executado, e' necessario que o "restore" seja feito antes
//	de um novo "save" ser executado.
//=======================================================================

void	backup_DEBUG ()
{
	SYS_DEBUG_backup = SYS_DEBUG_state;  // salva o status do Debug.
}
//***********************************************************************




//***********************************************************************
//	Faz o "restore" para implementar o mecanismo "save & restore"
//	do "Debug Dinamico".
//	O mecanismo nao pode ser encadeado, ou seja, apos o "save" ter
//	sido executado, e' necessario que o "restore" seja feito antes
//	de um novo "save" ser executado.
//=======================================================================

void	restore_DEBUG ()
{
	SYS_DEBUG_state = SYS_DEBUG_backup;  // restaura o status do Debug.
}
//***********************************************************************



#endif	// _Dynamic_Debug_cpp_

