

#ifndef	_SYS_types_cpp_   // garante processamento unico.
#define	_SYS_types_cpp_


// **********************************************************************
// **********************************************************************
// **
// **	Definicao de tipos e Macros para simplificar a codificacao
// **	de um programa para a Plataforma Arduino.
// **
// **	As definicoes podem referenciadas pelo #include do arquivo,
// **	ou copiadas diretamente para o codigo fonte, uma vez que
// **	esta assegurado o "processamento unico" mesmo para trechos
// **	individuais.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Arquivos de include utilizados:
//=======================================================================

#include "SYS_types_001.h"   // header com definicoes e prototipos.

//***********************************************************************




//***********************************************************************
//	Tabela para obtencao dos padroes de bits 0 a 7, atraves de
//	acesso indexado pelo proprio numero do bit. Os padroes na
//	Tabela sao do tipo BYTE, de forma a otimizar o acesso nos
//	Sistemas que usem apenas os bits 0 a 7.
//=======================================================================

ROM_set BYTE TAB_bit8 [] = { BIT_0, BIT_1, BIT_2, BIT_3, BIT_4, BIT_5, BIT_6, BIT_7 };

//***********************************************************************




//***********************************************************************
//	Tabela para obtencao dos padroes de bits 0 a 15, atraves de
//	acesso indexado pelo proprio numero do bit. Os padroes na
//	Tabela sao do tipo WORD, a fim de comportar os padroes para
//	a faixa de bits representada (0 a 15).
//=======================================================================

ROM_set WORD TAB_bit16 [] =
	{ BIT_0, BIT_1, BIT_2, BIT_3, BIT_4, BIT_5, BIT_6, BIT_7,
	  BIT_8, BIT_9, BIT_10, BIT_11, BIT_12, BIT_13, BIT_14, BIT_15 };

//***********************************************************************




//***********************************************************************
//	Retorna o padrao de bits para o bit especificado na faixa de
//	8 bits, ou seja, bits 0 a 7.
//=======================================================================

BYTE	bit8_Pattern_GET ( BYTE bit_N )
{
//--------------------------------------------------
BYTE PATTERN;
//--------------------------------------------------

	bit_N &= 0x07;   // garante que que o indice seja valido.

	PATTERN = ROM_get8( TAB_bit8 + bit_N );   // obtem padrao da Tabela.

	return ( PATTERN );   // retorna o padrao de bits requisitado.
}
//***********************************************************************




//***********************************************************************
//	Retorna o padrao de bits para o bit especificado na faixa de
//	16 bits, ou seja, bits 0 a 15.
//=======================================================================

WORD	bit16_Pattern_GET ( BYTE bit_N )
{
//--------------------------------------------------
WORD PATTERN;
//--------------------------------------------------

	bit_N = ( bit_N & 0x0F ) << 1;  // garante que que o indice seja valido.

	PATTERN = ROM_get16( TAB_bit16 + bit_N );   // obtem padrao da Tabela.

	return ( PATTERN );   // retorna o padrao de bits requisitado.
}
//***********************************************************************



#endif	// _SYS_types_cpp_

