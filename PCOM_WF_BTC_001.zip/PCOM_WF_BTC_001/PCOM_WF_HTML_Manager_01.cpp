

#ifndef	_PCOM_WF_HTML_Manager_cpp_   // garante processamento unico.
#define	_PCOM_WF_HTML_Manager_cpp_


// **********************************************************************
// **********************************************************************
// **
// **	Implementacao de um mecanismo sistematico para gerenciamento
// **	de Paginas HTML em um ESP32 configurado como WiFi Server. O
// **	mecanismo permite facilmente gerenciar uma grande quantidade
// **	de Paginas HTML, respondendo a comandos e atualizando paginas
// **	de acordo com estes comandos.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Arquivos de include utilizados:
//=======================================================================

#include "SYS_basics\Dynamic_Debug_001.h"   // utiliza o "Debug Dinamico".

#include "SYS_basics\SYS_types_001.h"  // definicoes auxiliares para o Sistema.

//-----------------------------------------------------------------------

#include "PCOM_WF_HTML_Manager_01.h"   // header com definicoes e prototipos.

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Gerenciamento do Timeout para atendimento do Cliente WiFi.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao do timeout default para o atendimento a um Cliente
//	HTML. Neste setting, o periodo de Timeout e' especificado em
//	segundos.
//=======================================================================

#define	WF_HTML_timeout_DEF   10   // default para o timeout, em segundos.

//***********************************************************************




//***********************************************************************
//	Variavel para o Timeout do atendimento a um Cliente HTML. O
//	valor default setado abaixo, esta' em unidades de mili-segundos.
//	O Timeout pode ser alterado a qualquer momento, usando a funcao
//	"WF_HTML_timeout_set" (e neste caso sera' especificado
//	em segundos, para facilidade de utilizacao da rotina).
//=======================================================================

unsigned long WF_HTML_timeout = em_segundos( WF_HTML_timeout_DEF );

//***********************************************************************




//***********************************************************************
//	Seta o Timeout para atendimento a um Cliente HTML. O periodo
//	e' especificado em unidades de segundos, para facilidade de
//	utilizacao da rotina. O Timeout pode ser alterado a qualquer
//	momento ("on the fly").
//=======================================================================

void	WF_HTML_timeout_set ( unsigned short timeout )
{
//--------------------------------------------------
unsigned long  timeout_ms;
//--------------------------------------------------

	timeout_ms = (unsigned long) 1000 * timeout;  // calcula em [ms].

	if ( timeout_ms < 5000 ) timeout_ms = 5000;   // garante periodo minimo.

	WF_HTML_timeout = timeout_ms;   // seta o novo timeout.
}
//***********************************************************************




//***********************************************************************
//	Gerencia o Timeout para o atendimento ao Cliente HTML. O uso
//	do Timeout, impede que o Cliente monopolize a atencao do
//	Sistema. Isto tambem permite que o restante do codigo continue
//	a executar (apos o Timeout), se por qualquer motivo o Cliente
//	inicie mas nao conclua uma requisicao. Se o Timeout ocorrer, a
//	conexao com o Cliente e' fechada, mas pode ser aberta novamente
//	a qualquer momento que o Cliente fizer nova requisicao.
//	Atraves da rotina e' possivel resetar a contagem de Timeout, ou
//	entao verificar se ocorreu o Timeout.
//=======================================================================

bool	WF_HTML_timeout_MANAGER ( bool reset )
{
//--------------------------------------------------
bool timeout = false;
static unsigned long ref_Tempo = 0;
unsigned long tempo;
//--------------------------------------------------

	if ( reset )   // se o Timeout deve ser resetado:
	{
		ref_Tempo = millis();	// reseta a contagem de Timeout.
	}
	else   // se o Timeout esta' sendo verificado:
	{
		tempo = millis();   // obtem a contagem de tempo atual.

		if ( ( tempo - ref_Tempo ) >= WF_HTML_timeout )  // se ocorreu Timeout:
		{
			timeout = true;   // indica que ocorreu o Timeout.
		}
	}

	return ( timeout );   // finaliza, indicando se ocorreu Timeout.
}
//***********************************************************************




//***********************************************************************
//	Reseta a contagem de Timeout para o atendimento a um Cliente
//	HTML.
//=======================================================================

void	WF_HTML_timeout_RESET ()
{
	WF_HTML_timeout_MANAGER( true );   // reseta a contagem de Timeout.
}
//***********************************************************************




//***********************************************************************
//	Verifica se ocorreu Timeout durante o atendimento a um Cliente
//	HTML.
//=======================================================================

bool	WF_HTML_timeout_Check ()
{
	return ( WF_HTML_timeout_MANAGER( false ) );   // retorna o resultado.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Mecanismo para Gerenciamento de Paginas HTML do Cliente.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Implementacao do Mecanismo para Gerenciamento de Paginas HTML
//	de um Cliente conectado via WiFi. Essencialmente, a rotina
//	gerencia a recepcao de requisicoes do Cliente (se um estiver
//	conectado). Quando uma requisicao e' completada, a rotina entao
//	chama a funcao que ira' processar a requisicao do Cliente,
//	passando para esta funcao a string correspondente a requisicao
//	(esta string normalmente e' enviada pelo navegador utilizado
//	pelo Cliente). A funcao a ser chamada (em um formato semelhante
//	a um "callback"), e' passada para esta rotina por quem chamou a
//	mesma, juntamente com o Cliente atual. Um timeout tambem esta'
//	implementado, caso o Cliente nao conclua a requisicao iniciada.
//	Quando o timeout ocorre, a requisicao e' descartada e a conexao
//	com o Cliente e' fechada, mas podera' ser reaberta se o Cliente
//	reconectar. Na saida, a rotina informa se alguma requisicao foi
//	recebida.
//=======================================================================

bool	WF_HTML_Manager ( WiFiClient* client_PTR, HTML_Proc_func HTML_Proc_PTR )
{
//--------------------------------------------------
String HTML_req_str = "";
bool ready = false;
bool request = false;
char c;
//--------------------------------------------------

	if ( (*client_PTR) )   // se ha' um Cliente conectado:
	{
		DEBUG_start( Serial.println( F("------------------------------------------") ) );  // bloco de Debug.
		DEBUG_end( Serial.println( F("===> iniciou HTML:") ) );

		WF_HTML_timeout_RESET();   // reseta contagem de timeout.

		while ( (*client_PTR).connected() && !ready )   // enquanto conectado e nao concluiu:
		{
			if ( (*client_PTR).available() )   // se recebeu um caracter do Cliente HTML:
			{
				request = true;   // indica que ocorreu uma requisicao.

				c = (*client_PTR).read();   // obtem o caracter enviado pelo Cliente HTML.

				DEBUG_line( Serial.write(c) );   // exibe no Terminal do Arduino, via debug.

				if ( HTML_req_str.length() < 50 )   // se a requisicao nao e' muito longa:
				{
					if ( c >= 0x20 ) HTML_req_str += c;   // acrescenta na string de requisicao.
				}

				if ( c == '\n' )   // se concluiu a requisicao HTML:
				{
					(*HTML_Proc_PTR) ( client_PTR, &HTML_req_str );   // processa a requisicao.

					ready = true;   // indica que concluiu uma requisicao.
				}
			}

			if ( WF_HTML_timeout_Check() )   // se ocorreu timeout esperando o Cliente:
			{
				DEBUG_line( Serial.println( F("===> timeout HTML!") ) );   // informa via debug.

				ready = true;   // indica que concluiu uma requisicao.
			}
		}

		(*client_PTR).stop();   // fecha a conexao atual.

		DEBUG_start();  // inicia bloco de Debug.
		Serial.println( F("===> finalizou HTML.") );
		Serial.println( F("------------------------------------------") );
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.
	}

	return ( request );   // informa se ocorreu uma requisicao.
}
//***********************************************************************



#endif	// _PCOM_WF_HTML_Manager_cpp_

