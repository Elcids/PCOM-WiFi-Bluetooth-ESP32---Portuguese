

#ifndef	_PCOM_WF_BTC_001_cpp_	// garante processamento unico.
#define	_PCOM_WF_BTC_001_cpp_


// **********************************************************************
// **********************************************************************
// **
// **	Descricao basica das funcionalidades:
// **
// **	Implementação de um Gerenciador para a Conexao Automatica de
// **	um Sistema baseado no ESP32 da Plataforma Arduino, em uma
// **	rede WiFi local ou em dispositivos Bluetooth (como Tablets,
// **	Smartphones, Computadores, etc), permitindo-se o controle
// **	deste Sistema atraves destas conexoes.
// **	O Gerenciador conecta-se automaticamente na conexao que esta'
// **	atualmente disponivel, seja WiFi ou Bluetooth. Se uma conexao
// **	e' perdida, entao o Gerenciador automaticamente procura se
// **	conectar na outra.
// **
// **	Para controle via Bluetooth, o dispositivo de conexao devera'
// **	usar Interface SPP (Serial Port Profile) via Bluetooth Classic.
// **	Para tal, o usuario pode criar seu proprio APP dedicado, ou
// **	usar qualquer APP de Terminal SPP (existem muitos, com os mais
// **	diversos recursos, por exemplo o "Serial Bluetooth Terminal" do
// **	desenvolvedor "Kai Morich", o qual utilizei nos testes deste
// **	Gerenciador). Ha' muitas possibilidades de controle, como o
// **	popular "Blink" e diversos outros semelhantes.
// **
// **	Para controle via WiFi local, pode-se utilizar uma Interface
// **	via Pagina HTML. Neste Gerenciador ha' recursos para facilitar
// **	tremendamente o gerenciamento de uma Interface HTML, inclusive
// **	utilizando-se quaisquer quantidades de paginas HTML, e de forma
// **	muito simples e eficiente. E pode-se tambem utilizar quaisquer
// **	outros Protocolos, sejam padroes ou dedicados.
// **
// **	No controle via Bluetooth Classic, foi criado um Mecanismo para
// **	a Autenticacao do Cliente via senha (pois a implementacao atual
// **	da Espressif nao usa senha de pareamento Bluetooth). E' exigida
// **	a Autenticacao de um Cliente uma unica vez, pois o Mecanismo
// **	salva na "EEPROM" do ESP32 a Lista de Clientes ja' autenticados.
// **	Nesta implementacao, o maximo de Clientes na Lista e' limitado
// **	a ate' 70 Clientes. Assim, o codigo atual sendo executado pelo
// **	ESP32 pode (a criterio do mesmo), permitir o acesso ao controle
// **	do Sistema, apenas quando um Cliente esta' autenticado.
// **
// **	No controle via WiFi local (ou mesmo via Internet, atraves de
// **	um "Port Foward"), a Autenticacao fica por conta do codigo atual
// **	sendo executado pelo ESP32, permitindo-se personalizar isto da
// **	forma desejada (onde provavelmente uma Pagina HTML solicitando
// **	uma Autenticacao com senha, seria uma das formas mais atrativas).
// **	Isto foi feito dessa forma, pois em rede WiFi local normalmente
// **	ja' existe Autenticacao atraves de senha. Entao isto da' maior
// **	flexibilidade para o usuario escolher a melhor forma que ele
// **	achar ser adequada para aumentar a seguranca do Sistema.
// **
// **	O Endereco IP no qual o ESP32 aparece, e' designado pela rede
// **	WiFi local, sendo exibido no Terminal do Arduino logo que o
// **	Sistema inicia.
// **	Este Endereco IP tambem e' acessivel a qualquer momento atraves
// **	da funcao "WiFi.localIP()" que e' tradicional no ESP32, e assim
// **	o usuario pode decidir a forma que ele considera a mais adequada
// **	para exibir o IP atual (por exemplo em um Display LCD no Sistema,
// **	o que pode ser feito neste ESP32 ou em um outro Arduino).
// **	Uma outra possibilidade muito conveniente, e' designar ao ESP32
// **	deste Sistema, um Endereco IP especifico, o que normalmente e'
// **	feito na pagina do Roteador da Rede WiFi local.
// **
// **	A Interface do Gerenciador (a "API"), e' bastante simples, e
// **	exige poucas declaracoes e chamadas de funcoes (atraves das quais
// **	pode-se tambem especificar senhas, timeouts diversos, resetar a
// **	Lista de Clientes Bluetooth, especificar o Modo de Comando para
// **	Autenticacao do Bluetooth, etc).
// **
// **	E' possivel tambem ligar-se o "Modo Debug", permitindo-se ver no
// **	Terminal do Arduino, as diversas ocorrencias no Gerenciador.
// **
// **
// **	Elcids H. das Chagas - agosto 2019
// **
// **********************************************************************
// **********************************************************************




//***********************************************************************
//	Definicao das Bibliotecas do ESP32 utilizadas neste Sistema:
//=======================================================================

#include "rom\crc.h"   // Lib do ESP32 para calculo de CRC.

#include "EEPROM.h"   // Lib para uso da "EEPROM" do ESP32.

#include "WiFi.h"   // Lib WiFi do ESP32.

//***********************************************************************




//***********************************************************************
//	Implementacoes desenvolvidas para este Sistema:
//=======================================================================

#include "SYS_basics\Dynamic_Debug_001.cpp"   // utiliza o "Debug Dinamico".

#include "SYS_basics\SYS_types_001.cpp"  // definicoes auxiliares para este Sistema.

//-----------------------------------------------------------------------

#include "new_BTC_SPP\new_BTC_SPP_rev_001.cpp"   // Implementacao da Interface SPP.

//-----------------------------------------------------------------------

#include "PCOM_WF_HTML_Manager_01.h"   // Mecanismo Gerenciador de Paginas HTML.

//-----------------------------------------------------------------------

#include "PCOM_WF_BTC_001.h"   // Implementacao da Interface do PCOM WiFi/Bluetooth.

//***********************************************************************




//***********************************************************************
//	Definicoes para a Conexao WiFi utilizada no Sistema.
//	Altere conforme a rede WiFi disponivel, ou entao utilize a
//	funcao "WF_BT_Server_param_SET" para setar estes parametros.
//=======================================================================


String WiFi_ssid = "nome_WiFi";   // nome da Rede WiFi.

String WiFi_password = "senha_WiFi";   // senha da Rede WiFi.

//-----------------------------------------------------------------------

unsigned short WiFi_SERVER_PORT = 80;	// Porta da Conexao TCP/IP do WiFi Server.

//***********************************************************************




//***********************************************************************
//	Definicao do nome para o dispositivo Bluetooth implementado
//	neste Sistema.
//	Este e' o nome que aparecera' na busca de dispositivos Bluetooth
//	para pareamento em Smartphones, Tablets, e Computadores.
//	Altere conforme desejado, ou entao especifique o nome atraves
//	da funcao "WF_BT_Server_param_SET".
//=======================================================================

String nome_BLUETOOTH = "BTC_SPP";   // nome deste Bluetooth Device.

//***********************************************************************




//***********************************************************************
//	Definicao da senha para Autenticacao via Bluetooth neste
//	Sistema. Altere conforme desejado, ou entao utilize a funcao
//	"WF_BT_Server_param_SET" para especificar esta senha.
//	Atencao: esta nao e' a senha de pareamento tradicional para
//	dispositivos Bluetooth. Esta e' a senha de Autenticacao para
//	acesso ao controle do Sistema via SPP Bluetooth.
//=======================================================================

String BTC_password = "senha_BTC";   // senha de Autenticacao via Bluetooth.

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Definicoes compartilhadas entre as Maquinas de Estados que
//	gerenciam as conexoes deste Sistema.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao dos Eventos do Sistema, que sao sinalizados para
//	as diversas Maquinas de Estados:
//=======================================================================

enum	// eventos:
{
	evento_nenhum,		// indica que nao ha' evento.

// - - - - - - - - - - - -

	evento_conectar_WF,	// evento para sinalizar que o WiFi deve ser conectado.

	evento_desconectar_WF,	// evento para sinalizar que o WiFi deve ser desconectado.

	evento_conectou_WF,	// evento para sinalizar que o WiFi foi conectado.

	evento_desconectou_WF,	// evento para sinalizar que o WiFi foi desconectado.

	evento_timeout_WF,	// evento para sinalizar timeout esperando Conexao WiFi.

// - - - - - - - - - - - -

	evento_conectar_BT,	// evento para sinalizar que o Bluetooth deve ser conectado.

	evento_desconectar_BT,	// evento para sinalizar que o Bluetooth deve ser desconectado.

	evento_conectou_BT,	// evento para sinalizar que o Bluetooth foi conectado.

	evento_desconectou_BT,	// evento para sinalizar que o Bluetooth foi desconectado.

	evento_timeout_BT,	// evento para sinalizar timeout esperando Conexao Bluetooth.

// - - - - - - - - - - - -

	evento_req_senha_BT,	// evento para requisitar Senha para Autenticacao Bluetooth.

	evento_Cliente_Aut_BT,	// evento para sinalizar Cliente Bluetooth autenticado.

	evento_Cliente_NoAut_BT,   // evento para sinalizar Cliente Bluetooth NAO-autenticado.
};
//***********************************************************************




//***********************************************************************
//	Definicao das Variaveis para Sinalizar Eventos do Sistema que
//	sao sinalizados para as diversas Maquinas de Estados:
//=======================================================================

byte	evento_Gerencia_WiFi = evento_nenhum;  // inicialmente, indica "nenhum evento".

byte	evento_Gerencia_BT = evento_nenhum;   // inicialmente, indica "nenhum evento".

byte	evento_Cliente_BT = evento_nenhum;   // inicialmente, indica "nenhum evento".

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Definicoes compartilhadas entre as Maquinas de Estados que
//	utilizam o PCOM Bluetooth como meio de conexao neste Sistema.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicoes relacionadas ao Modo de Comando utilizado para o
//	envio/recebimento de comandos atraves do PCOM Bluetooth, seja
//	para o processo de Autenticaco, seja para outros processos de
//	controle interno do PCOM Bluetooth.
//
//	Nesta implementacao, dois modos estao disponiveis:
//
//	1 = Modo Simples: comandos se iniciam com '#' e sao constituidos
//	por sequencias simples em ASCII. Os comandos sempre terminam com
//	a sequencia "Carriage Return" e "New Line", ou seja, os caracteres
//	nao-imprimiveis 0x0D e 0x0A, que na linguagem C sao tambem chamados
//	de '\r' e '\n'. O modo simples e' indicado quando os comandos serao
//	interpretados por outro programa ou uma maquina similar, pois este
//	formato simplifica o processo de decodificacao.
//	Exemplo: #TA , significa "Timeout de Autenticacao".
//
//	2 = Modo Texto: comandos se iniciam com '$' e sao constituidos por
//	palavras/texto "legiveis" em ACII. Os comandos sempre terminam com
//	a sequencia "Carriage Return" e "New Line", ou seja, os caracteres
//	nao-imprimiveis 0x0D e 0x0A, que na linguagem C sao tambem chamados
//	de '\r' e '\n'. O modo Texto e' indicado quando os comandos serao
//	interpretados por pessoas, ou seja, quando os caracteres do comando
//	sao exibidos em algo semelhante a uma caixa de dialogo ou Terminal
//	de Texto.
//	Exemplo: $ terminou tempo!!! , indicando Timeout de Autenticacao.
//
//=======================================================================

byte  BT_CMD_mode = BT_CMD_simples;  // modo atual de comando do PCOM BT.

//***********************************************************************




//***********************************************************************
//	Instanciamento do SPP (Serial Port Profile) Bluetooth, para a
//	Interface entre um Cliente e o PCOM Bluetooth neste Sistema:
//=======================================================================

BTC_Serial   System_SPP;   // instancia a Interface "SPP" Bluetooth.

//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Rotinas de suporte ao Registro e Mecanismo de Autenticaco
//	de Clientes Bluetooth deste Sistema.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicoes para Registro dos Clientes Bluetooth autenticados
//	neste Sistema.
//	Atencao: o maximo de Clientes autenticados esta' vinculado ao
//	tamanho da EEPROM disponivel no ESP32, e portanto nao deve ser
//	aumentado (mas pode ser diminuido).
//=======================================================================

#define	BTC_Client_max	70   // numero maximo de Clientes autenticados.

#define	BTC_PIN_info_res    80   // tamanho da area reservada no "BTC_PIN_info".

//-----------------------------------------------------------------------

struct	BTC_PIN_info   // estrutura para controle de Clientes autenticados:
{
	DWORD SIGN;   // Assinatura de Validacao do "BTC_PIN_info".

	WORD ID;    // Identificador do formato/versao  do "BTC_PIN_info".

	WORD CRC16;   // CRC da Lista de Clientes Bluetooth autenticados.

	byte reservado [BTC_PIN_info_res];   // area reservada.

	BTC_Client_PIN_type Client_PIN_list [BTC_Client_max];   // Lista de Clientes autenticados.
};

//-----------------------------------------------------------------------

typedef	struct BTC_PIN_info   BTC_PIN_frame;  // definicao de tipo para facilitar codificacao.

//-----------------------------------------------------------------------

#define	BTC_PIN_frame_size   sizeof( BTC_PIN_frame )  // tamanho do "BTC_PIN_frame".

//***********************************************************************




//***********************************************************************
//	Instanciamento da Estrutura para Controle dos Clientes
//	Bluetooth autenticados:
//=======================================================================

BTC_PIN_frame	BTC_PIN_data;  // estrutura para controle de Clientes autenticados.

//-----------------------------------------------------------------------

#define	PIN_list_size   sizeof( BTC_PIN_data.Client_PIN_list )  // tamanho da Lista de Clientes.

//***********************************************************************




//***********************************************************************
//	Definicao da Assinatura de Validacao e do Identificador
//	do formato/versao para a Estrutura de Controle de Clientes
//	autenticados.
//=======================================================================

#define	BTC_PIN_SIGN    0x87654321   // Assinatura de Validacao do "BTC_PIN_info".

//-----------------------------------------------------------------------

#define	BTC_PIN_ID    0x0100   // Identificador do formato/versao do "BTC_PIN_info".

//***********************************************************************




//***********************************************************************
//	Flags de Validacao para acessar a EEPROM neste Sistema, e
//	da Lista atual de Clientes Bluetooth Autenticados:
//=======================================================================

bool	BT_EEPROM_Ok = false;   // indica se a Memoria EEPROM pode ser acessada.

bool	BT_Client_List_Ok = false;   // indica se a Lista de Clientes e' valida.

//***********************************************************************




//***********************************************************************
//	Verifica se a EEPROM do ESP32 foi inicializada, a fim de ser
//	ser usada para a Lista de Clientes Bluetooth Autenticados. Se
//	a EEPROM nao foi inicializada, a rotina faz a inicializacao e
//	atualiza a flag "BT_EEPROM_Ok". Na saida, a rotina informa se
//	a inicializacao foi feita com sucesso.
//=======================================================================

bool	BT_EEPROM_check ()
{
	if ( !BT_EEPROM_Ok )   // se a EEPROM nao foi inicializada:
	{
		if ( EEPROM.begin( BTC_PIN_frame_size ) )  // se e' possivel acessar a EEPROM:
		{
			BT_EEPROM_Ok = true;   // valida o acesso a EEPROM.
		}
		else   // se NAO e' possivel acessar a EEPROM, informa via Terminal:
		{
			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("falha ao inicializar EEPROM !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}

	return ( BT_EEPROM_Ok );  // informa se a EEPROM foi inicializada.
}
//***********************************************************************




//***********************************************************************
//	Salva na EEPROM do ESP32, a Estrutura de Controle de Clientes
//	Bluetooth Autenticados. Na saida, a rotina informa se teve
//	sucesso na operacao de gravacao.
//=======================================================================

bool	BT_Client_List_SAVE ()
{
//--------------------------------------------------
bool Ok = false;
WORD CRC16;
//--------------------------------------------------

	if ( BT_EEPROM_check() )   // se e' possivel acessar a EEPROM:
	{
		BTC_PIN_data.SIGN = BTC_PIN_SIGN;   // seta a Assinatura da Estrutura de Controle.

		BTC_PIN_data.ID = BTC_PIN_ID;   // seta o Identificador do formato/versao.

		CRC16 = crc16_le( 0, (byte*) &BTC_PIN_data.reservado, BTC_PIN_info_res );  // calcula o CRC da area resevada.

		CRC16 = crc16_le( CRC16, (byte*) &BTC_PIN_data.Client_PIN_list, PIN_list_size );  // inclui o CRC da Lista de Clientes.

		BTC_PIN_data.CRC16 = CRC16;   // seta o CRC atual.

		BT_Client_List_Ok = true;   // registra que a Lista atual e' valida.

		DEBUG_start();  // inicia bloco de Debug.
		Serial.println();
		Serial.print( F("gravando Lista BT com CRC = ") );
		Serial.print( CRC16, HEX );
		Serial.println('H');
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.

		EEPROM.writeBytes( 0, (void*) &BTC_PIN_data, BTC_PIN_frame_size );  // envia Estrutura para ser gravada na EEPROM.

		Ok = EEPROM.commit();	// faz gravacao efetiva da Estrutura na EEPROM do ESP32.
	}

	return ( Ok );   // informa se teve sucesso na gravacao.
}
//***********************************************************************




//***********************************************************************
//	Restaura da EEPROM, a Estrutura para o Controle da Lista de
//	Clientes Bluetooth autenticados neste Sistema.
//	Primeiro a rotina verifica se e' possivel acessar a EEPROM,
//	e caso seja, ela copia a Estrutura residente na EEPROM para
//	a Estrutura de Controle atual do Sistema. Entao e' verificado
//	se a Estrutura lida da EEPROM e' valida, e caso seja, isto e'
//	informado na saida.
//=======================================================================

bool	BT_Client_List_RESTORE ()
{
//--------------------------------------------------
WORD CRC16;
//--------------------------------------------------

	BT_Client_List_Ok = false;   // invalida a Lista atual de Clientes.

	if ( BT_EEPROM_check() )   // se e' possivel acessar a EEPROM:
	{
		EEPROM.readBytes( 0, (void*) &BTC_PIN_data, BTC_PIN_frame_size );  // le Estrutura residente na EEPROM.

		if ( BTC_PIN_data.SIGN == BTC_PIN_SIGN )   // se a Assinatura dessa Estrutura e' valida:
		{
			CRC16 = crc16_le( 0, (byte*) &BTC_PIN_data.reservado, BTC_PIN_info_res );  // calcula o CRC da area resevada.

			CRC16 = crc16_le( CRC16, (byte*) &BTC_PIN_data.Client_PIN_list, PIN_list_size );  // inclui o CRC da Lista de Clientes.

			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.print( F("CRC da Lista BT na EEPROM = ") );   // informa o CRC gravado na EEPROM.
			Serial.print( BTC_PIN_data.CRC16, HEX );
			Serial.println('H');

			Serial.print( F("CRC da Lista BT calculado = ") );   // informa o CRC recalculado.
			Serial.print( CRC16, HEX );
			Serial.println('H');
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.

			if ( CRC16 == BTC_PIN_data.CRC16 )  BT_Client_List_Ok = true;   // se o CRC coincide, valida a Lista atual.
		}
		else   // se a Assinatura da Estrutura e' invalida, informa via Terminal:
		{
			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("falha na Assinatura da Lista BT !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}

	return ( BT_Client_List_Ok );  // informa o resultado da restauracao da Lista.
}
//***********************************************************************




//***********************************************************************
//	Reseta a Estrutura para o Controle da Lista de Clientes
//	Bluetooth autenticados neste Sistema.
//	Primeiro, a rotina seta os valores default na Estrutura atual
//	para Controle da Lista. Entao a rotina salva na EEPROM esta
//	Estrutura resetada, e informa na saida se teve sucesso nesta
//	operacao de gravacao na EEPROM do ESP32.
//=======================================================================

bool	BT_Client_list_RESET ()
{
//--------------------------------------------------
bool Ok;
byte n, i;
//--------------------------------------------------

	for ( n = 0; n < BTC_PIN_info_res; n++ )  // reseta a area reservada:
	{
		BTC_PIN_data.reservado [n] = 0;  // valor default = 0.
	}

//..................................................

	for ( n = 0; n < BTC_Client_max; n++ )  // reseta a Lista de Clientes:
	{
		for ( i = 0; i < 6; i++ )   // zera todos os "PINs" na Lista:
		{
			BTC_PIN_data.Client_PIN_list [n] [i] = 0;
		}
	}

//..................................................

	Ok = BT_Client_List_SAVE();   // salva a Estrutura atual na EEPROM.

	if ( !Ok )   // se falhou ao salvar, informa via Terminal Serial:
	{
		DEBUG_start();  // inicia bloco de Debug.
		Serial.println();
		Serial.println( F("falha ao salvar Lista BT !!!") );
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.
	}

	return ( Ok );   // informa se teve sucesso na gravacao.
}
//***********************************************************************




//***********************************************************************
//	Procura na Lista de Clientes Bluetooth, o "PIN" especificado.
//	Se este "PIN" foi encontrado na Lista de Clientes, na saida
//	a rotina informa o indice logico desse PIN na Lista (o primeiro
//	indice logico valido e' "1"). Se o "PIN" nao foi encontrado na
//	Lista, entao a rotina informa um indice igual a "0" (zero).
//=======================================================================

byte	BT_Client_list_SEARCH ( BTC_Client_PIN_type Client_PIN )
{
//--------------------------------------------------
bool Ok = false;
byte n, i;
//--------------------------------------------------

	n = 0;   // indice fisico para iniciar busca na Lista.

	while ( ( n < BTC_Client_max ) && !Ok )  // se nao e' o fim da Lista, nem encontrou o "PIN":
	{
		Ok = true;  // inicialmente, indica coincidencia.

		i = 0;   // indice inicial para comparar bytes individuais do "PIN".

		while ( Ok && ( i < 6 ) )  // enquanto os bytes coincidem e nao terminou a comparacao:
		{
			if ( BTC_PIN_data.Client_PIN_list [n] [i] != Client_PIN [i] )  // se um byte e' diferente:
			{
				Ok = false;   // indica que este "PIN" da Lista nao coincide.
			}

			i++;   // aponta proximo byte para comparacao dos PINs.
		}

		n++;   // aponta proximo "PIN" na Lista de Clientes.
	}

	if ( !Ok ) n = 0;   // se nao encontrou o "PIN" na Lista, zera o indice logico.

	return ( n );   // informa o indice logico.
}
//***********************************************************************




//***********************************************************************
//	Insere na Lista de Clientes Bluetooth, o "PIN" especificado.
//	A rotina procura uma vaga na Lista atual de Clientes. Se nao
//	encontrou uma vaga, a rotina termina informando que o PIN nao
//	foi salvo na EEPROM. Se encontrou uma vaga, a rotina insere
//	o PIN nesta vaga, e entao salva na EEPROM a Estrutura para o
//	Controle da Lista de Clientes. Na saida a rotina informa se
//	a operacao de salvar (gravacao) foi executada com sucesso.
//=======================================================================

bool	BT_Client_list_INSERT ( BTC_Client_PIN_type Client_PIN )
{
//--------------------------------------------------
bool Ok = false;
BTC_Client_PIN_type null_PIN = { 0, 0, 0, 0, 0, 0 };
byte n, i;
//--------------------------------------------------

	n = BT_Client_list_SEARCH( null_PIN );  // procura uma vaga na Lista de Clientes.

	if ( n != 0 )   // se encontrou uma vaga na Lista:
	{
		n--;   // ontem o indice fisico desta vaga.

		for ( i = 0; i < 6; i++ )  // copia para esta vaga, o "PIN" especificado:
		{
			BTC_PIN_data.Client_PIN_list [n] [i] = Client_PIN [i];
		}

		Ok = BT_Client_List_SAVE();   // salva a Estrutura atual na EEPROM.

		if ( !Ok )   // se falhou ao salvar, informa via Terminal Serial:
		{
			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("falha ao salvar Lista BT !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}
	else   // se NAO encontrou uma vaga na Lista, informa via Terminal:
	{
		DEBUG_start();  // inicia bloco de Debug.
		Serial.println();
		Serial.println( F("Lista BT cheia !!!") );
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.
	}

	return ( Ok );   // informa se teve sucesso na gravacao.
}
//***********************************************************************




//***********************************************************************
//	Verifica se o "PIN" especificado e' "nulo" (ou seja, se todos
//	os 6 bytes do "PIN" sao zero).
//=======================================================================

bool	BT_Client_PIN_null_CHECK ( BTC_Client_PIN_type* Client_PIN_PTR )
{
//--------------------------------------------------
bool Ok = false;
byte data, i;
//--------------------------------------------------

	data = 0;   // zera byte para iniciar verificacao.

	for ( i = 0; i < 6; i++ )   // para todos os bytes do "PIN":
	{
		data |= (*Client_PIN_PTR) [i];  // registra se algum byte nao e' "0".
	}

	if ( data == 0 ) Ok = true;   // se todos os bytes eram "0", indica isto.

	return ( Ok );   // informa se o "PIN" especificado e' nulo.
}
//***********************************************************************




//***********************************************************************
//	Seta o "PIN" especificado em "nulo" (ou seja, coloca todos
//	os 6 bytes do "PIN" em zero).
//=======================================================================

void	BT_Client_PIN_null_SET ( BTC_Client_PIN_type* Client_PIN_PTR )
{
//--------------------------------------------------
byte i;
//--------------------------------------------------

	for ( i = 0; i < 6; i++ )   // para cada byte do "PIN":
	{
		(*Client_PIN_PTR) [i] = 0;  // zera este byte.
	}
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Gerenciamento da Maquina de Estados que faz o processo de
//	Autenticacao de um Cliente SPP Bluetooth neste Sistema.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicoes default dos parametros que controlam o processo
//	de Autenticacao de um Cliente SPP Bluetooth. Os valores estao
//	especificados em segundos, para facilidade de uso.
//=======================================================================

#define	MAX_tent_Senha_Autentic_BT_def   3  // default do maximo de tentativas de senhas incorretas, em segundos.

#define	Timeout_Autentic_BT_def   45   // defaul do timeout para o processo de Autenticacao, em segundos.

//***********************************************************************




//***********************************************************************
//	Variaveis para os parametros que controlam o processo de
//	Autenticacao de um Cliente SPP Bluetooth.
//	Os valores destas variaveis estao sempre em mili-segundos.
//=======================================================================

byte  MAX_tent_Senha_Autentic_BT = MAX_tent_Senha_Autentic_BT_def;  // maximo de tentativas de senhas incorretas.

unsigned long  Timeout_Autentic_BT = em_segundos( Timeout_Autentic_BT_def );  // timeout para o processo de Autenticacao.

//***********************************************************************




//***********************************************************************
//	Verifica se o timeout atual para o processo de Autenticacao
//	de um Cliente SPP Bluetooth, e' coerente com o numero maximo
//	de tentativas de Autenticacao. Cada tentativa corresponde a
//	uma digitacao de senha, e o Sistema considera um tempo de 15
//	segundos para cada tentativa. Se o timeout for incoerente,
//	a rotina seta este timeout em coerencia com o tempo para cada
//	tentativa.
//=======================================================================

void	valida_Timeout_Autentic_BT ()
{
//--------------------------------------------------
unsigned long  timeout_min;
//--------------------------------------------------

	timeout_min = (long) 15000 * MAX_tent_Senha_Autentic_BT;  // calcula um timeout coerente.

	if ( Timeout_Autentic_BT < timeout_min )   // se o timeout atual e' incoerente:
	{
		Timeout_Autentic_BT = timeout_min;  // seta o valor coerente para o timeout.
	}
}
//***********************************************************************




//***********************************************************************
//	Informa ao Cliente SPP Bluetooth, que terminou o tempo que
//	ele tinha para fazer a Autenticacao neste Sistema.
//	O informe e' feito conforme o modo de comando atualmente sendo
//	utilizado.
//=======================================================================

void	envia_MSG_timeout_Senha_SPP_BT ()
{
	if ( BT_CMD_mode == BT_CMD_simples )  // se modo "comando simples":
	{
		System_SPP.println( F("#TA") );   // informa "Timeout de Autenticacao".
	}
	else if ( BT_CMD_mode == BT_CMD_texto )   // se modo "comando texto":
	{
		System_SPP.println();
		System_SPP.println( F("$ terminou tempo!!!") );
	}
}
//***********************************************************************




//***********************************************************************
//	Informa ao Cliente SPP Bluetooth, que esta' incorreta a senha
//	que ele forneceu para Autenticacao neste Sistema.
//	O informe e' feito conforme o modo de comando atualmente sendo
//	utilizado.
//=======================================================================

void	envia_MSG_falha_Senha_SPP_BT ()
{
	if ( BT_CMD_mode == BT_CMD_simples )  // se modo "comando simples":
	{
		System_SPP.println( F("#SI") );   // informa "Senha Incorreta".
	}
	else if ( BT_CMD_mode == BT_CMD_texto )   // se modo "comando texto":
	{
		System_SPP.println();
		System_SPP.println( F("$ senha incorreta!!!") );
	}
}
//***********************************************************************




//***********************************************************************
//	Informa ao Cliente SPP Bluetooth, que esta' correta a senha
//	que ele forneceu para Autenticacao neste Sistema, e que ele
//	tem permissao para acessar e controlar este Sistema.
//	O informe e' feito conforme o modo de comando atualmente sendo
//	utilizado.
//=======================================================================

void	envia_MSG_Ok_Senha_SPP_BT ()
{
	if ( BT_CMD_mode == BT_CMD_simples )  // se modo "comando simples":
	{
		System_SPP.println( F("#AC") );   // informa "Acesso Concedido".
	}
	else if ( BT_CMD_mode == BT_CMD_texto )   // se modo "comando texto":
	{
		System_SPP.println();
		System_SPP.println( F("$ senha correta.") );
		System_SPP.println( F("$ acesso concedido.") );
		System_SPP.println();
	}
}
//***********************************************************************




//***********************************************************************
//	Informa ao Cliente SPP Bluetooth, que ele deve fornecer uma
//	senha para Autenticacao neste Sistema.
//	O informe e' feito conforme o modo de comando atualmente sendo
//	utilizado.
//=======================================================================

void	envia_MSG_req_Senha_SPP_BT ()
{
	if ( BT_CMD_mode == BT_CMD_simples )  // se modo "comando simples":
	{
		System_SPP.println( F("#RS") );   // informa que "requer senha".
	}
	else if ( BT_CMD_mode == BT_CMD_texto )   // se modo "comando texto":
	{
		System_SPP.println();
		System_SPP.println( F("$ entre com a senha de acesso:") );
	}
}
//***********************************************************************




//***********************************************************************
//	Recebe a senha de Autenticacao enviada por um Cliente SPP
//	Bluetooth. A senha e' lida caractere por caractere, e deve
//	terminar com um caracter "new line" (ou seja, '\n'). Se a
//	senha e' recebida por completo, a rotina termina informando
//	isso e tambem a senha recebida (o caractere '\n' e' descartado).
//	Se a senha nao foi recebida por completo (sem o caracter '\n'),
//	entao a rotina termina indicando esta condicao, e neste caso a
//	rotina deve ser novamente chamada para continuar a receber a
//	senha, ate' que esteja completa.
//	O comprimento maximo para uma senha, sao 16 caracteres, e
//	qualquer caractere a mais sera' ignorado. Neste caso, a rotina
//	termina e considera como senha os 16 caracteres recebidos.
//	Qualquer caractere ASCII "nao imprimivel" tambem e' ignorado.
//=======================================================================

bool	obtem_Senha_SPP_BT ( String* senha )
{
//--------------------------------------------------
bool ready = false;
char c;
//--------------------------------------------------

	while ( System_SPP.available() && !ready )  // se nao recebeu senha por completo:
	{
		c = System_SPP.read();   // le o caractere recebido.

		if ( (*senha).length() <= 16 )  // se nao ultrapassou limite de tamanho:
		{
			if ( c >= 0x20 )   // se o caractere e' imprimivel:
			{
				(*senha) += c;  // inclui este caractere na senha.
			}
			else if ( c == '\n' )   // se e' um caractere "new line":
			{
				ready = true;   // indica que concluiu a recepcao da senha.
			}
		}
		else ready = true;  // se ultrapassou limite de tamanho, conclui recepcao.
	}

	return ( ready );   // informa se concluiu a recepcao da senha.
}
//***********************************************************************




//***********************************************************************
//	Definicao dos estados da Maquina de Estados que faz o processo
//	de Autenticacao de um Cliente SPP Bluetooth neste Sistema:
//=======================================================================

enum	// estados do processo de Autenticacao:
{
	estado_inicio_senha,	// estado para iniciar o processo de Autenticacao.

	estado_requisitar_senha,   // estado para requisitar a senha de Autenticacao.

	estado_receber_senha,	// estado para receber a senha de Autenticacao.
};
//***********************************************************************




//***********************************************************************
//	Implementacao da Maquina de Estados que faz o processo de
//	Autenticacao de um Cliente SPP Bluetooth neste Sistema.
//=======================================================================

byte	MAQUINA_Autenticar_BT ( byte evento_externo )
{
//--------------------------------------------------
static byte ESTADO_Autenticar = estado_inicio_senha;
static String senha = "";
static byte tentativas;
static unsigned long ref_Tempo;
//--------------------------------------------------

//..................................................

	if ( ESTADO_Autenticar == estado_inicio_senha )   // se esta' no estado "inicio":
	{
		if ( evento_externo == evento_req_senha_BT )   // se deve fazer Autenticacao:
		{
			evento_externo = evento_nenhum;   // reseta indicador de evento.

			tentativas = 0;   // reseta contador de tentativas.

			ref_Tempo = millis();   // inicia contagem do timeout de Autenticacao.

			ESTADO_Autenticar = estado_requisitar_senha;   // vai para o estado "requisita senha".
		}
	}

//..................................................

	if ( ESTADO_Autenticar == estado_requisitar_senha )   // se esta' no estado "requisita senha":
	{
		envia_MSG_req_Senha_SPP_BT();   // solicita ao Cliente Bluetooth, a senha de Autenticacao.

		senha = "";   // reseta senha a ser enviada pelo Cliente.

		ESTADO_Autenticar = estado_receber_senha;   // vai para o estado "recebe senha".
	}

//..................................................

	if ( ESTADO_Autenticar == estado_receber_senha )   // se esta' no estado "recebe senha":
	{
		if ( evento_externo == evento_desconectou_BT )   // se o Cliente desconectou:
		{
			evento_externo = evento_Cliente_NoAut_BT;   // gera evento indicando que o Cliente NAO autenticou.

			ESTADO_Autenticar = estado_inicio_senha;   // vai para o estado "inicio".
		}
		else if ( obtem_Senha_SPP_BT( &senha ) )   // se o Cliente enviou uma senha:
		{
			if ( BTC_password.equals( senha ) )   // se a senha esta' correta:
			{
				envia_MSG_Ok_Senha_SPP_BT();   // informa ao Cliente Bluetooth que autenticou.

				evento_externo = evento_Cliente_Aut_BT;   // gera evento indicando que o Cliente autenticou.

				ESTADO_Autenticar = estado_inicio_senha;   // vai para o estado "inicio".
			}
			else   // se a senha esta' incorreta:
			{
				tentativas++;   // incrementa contador de tentativas.

				if ( tentativas < MAX_tent_Senha_Autentic_BT )   // se ainda ha' tentativas:
				{
					envia_MSG_falha_Senha_SPP_BT();   // informa ao Cliente que a senha esta' incorreta.

					ESTADO_Autenticar = estado_requisitar_senha;   // vai para o estado "requisita senha".
				}
				else   // se acabaram as tentativas:
				{
					envia_MSG_falha_Senha_SPP_BT();   // informa isso ao Cliente Bluetooth.

					evento_externo = evento_Cliente_NoAut_BT;  // gera evento indicando que o Cliente NAO autenticou.

					ESTADO_Autenticar = estado_inicio_senha;   // vai para o estado "inicio".
				}
			}
		}
		else if ( ( millis() - ref_Tempo ) >= Timeout_Autentic_BT )  // se ocorreu timeout de Autenticacao:
		{
			envia_MSG_timeout_Senha_SPP_BT();   // informa isso ao Cliente Bluetooth.

			evento_externo = evento_Cliente_NoAut_BT;   // gera evento indicando que o Cliente NAO autenticou.

			ESTADO_Autenticar = estado_inicio_senha;   // vai para o estado "inicio".
		}
	}

//..................................................

	return ( evento_externo );   // informa se ocorreu algum evento.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Gerenciamento da Maquina de Estados que controla o acesso
//	de Clientes Bluetooth a este Sistema.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao do valor default para o intervalo de espera ate'
//	que se inicie um novo ciclo de Autenticacao de um Cliente
//	SPP Bluetooth. O intervalo so' ocorre se o Cliente falhar
//	na Autenticacao ou se ele desconectar durante esse processo.
//	O valor esta' especificado em segundos, para facilidade de
//	utilizacao.
//=======================================================================

#define	intervalo_Autentic_BT_def   60  // default do intervalo, em segundos.

//***********************************************************************




//***********************************************************************
//	Variavel para o intervalo de espera ate' que se inicie um
//	novo ciclo de Autenticacao de um Cliente SPP Bluetooth. O
//	intervalo so' ocorre se o Cliente falhar na Autenticacao,
//	ou se ele desconectar durante esse processo. O valor dessa
//	variavel esta' sempre em mili-segundos.
//=======================================================================

unsigned long  intervalo_Autentic_BT = em_segundos( intervalo_Autentic_BT_def );

//***********************************************************************




//***********************************************************************
//	Informa ao Cliente SPP Bluetooth, que ele pode fazer uma nova
//	tentativa de Autenticacao neste Sistema, apos um intervalo de
//	tempo atualmente definido, em segundos.
//	O informe e' feito conforme o modo de comando atualmente sendo
//	utilizado.
//=======================================================================

void	envia_MSG_intervalo_Autentic_BT ()
{
	if ( BT_CMD_mode == BT_CMD_simples )  // se modo "comando simples":
	{
		System_SPP.print( F("#IA") );   // informa "Intervalo de Autenticacao".
		System_SPP.println( intervalo_Autentic_BT / 1000 );
	}
	else if ( BT_CMD_mode == BT_CMD_texto )   // se modo "comando texto":
	{
		System_SPP.println();
		System_SPP.print( F("$ tente daqui a ") );
		System_SPP.print( intervalo_Autentic_BT / 1000 );
		System_SPP.println( F(" segundos.") );
	}
}
//***********************************************************************




//***********************************************************************
//	Informa ao Cliente Bluetooth que ele tem acesso permitido,
//	pois esta' na Lista de Autenticacao deste Sistema.
//	O informe e' feito conforme o modo de comando atualmente sendo
//	utilizado.
//=======================================================================

void	envia_MSG_Cliente_na_Lista_BT ()
{
	if ( BT_CMD_mode == BT_CMD_simples )  // se modo "comando simples":
	{
		System_SPP.println( F("#AC") );   // informa "Acesso Concedido".
	}
	else if ( BT_CMD_mode == BT_CMD_texto )  // se modo "comando texto":
	{
		System_SPP.println();
		System_SPP.println( F("$ acesso concedido!") );
		System_SPP.println();
	}
}
//***********************************************************************




//***********************************************************************
//	Definicao dos estados da Maquina de Estados que controla o
//	acesso de Clientes Bluetooth a este Sistema.
//=======================================================================

enum	// estados do controle do acesso:
{
	estado_restaurar_Lista,	// estado para restaurar a Lista de Clientes.

	estado_resetar_Lista,	// estado para resetar a Lista de Clientes.

	estado_esperar_Cliente,	// estado para esperar que um Cliente se conecte.

	estado_verificar_Cliente,  // estado para verificar se o Cliente esta' na Lista de Clientes.

	estado_autenticar_Cliente,  // estado para Autenticar o Cliente atualmente conectado.

	estado_registrar_Cliente,  // estado para registrar um Cliente na Lista de Clientes.

	estado_intervalo_Autentic,  // estado de espera, ate' a proxima Autenticacao.
};
//***********************************************************************




//***********************************************************************
//	Implementacao da Maquina de Estados que controla o acesso de
//	Clientes Bluetooth a este Sistema.
//=======================================================================

byte	MAQUINA_Cliente_BT ( byte evento_externo )
{
//--------------------------------------------------
static byte ESTADO_CLIENTE_BT = estado_restaurar_Lista;
static byte evento_Cliente = evento_nenhum;
static BTC_Client_PIN_type Client_PIN;
static unsigned long ref_Tempo;
//--------------------------------------------------

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_restaurar_Lista )   // se esta' no estado "restaurar Lista":
	{
		if ( BT_Client_List_RESTORE() )   // se a Lista de Clientes Bluetooth e' valida:
		{
			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("carregou Lista BT.") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.

			ESTADO_CLIENTE_BT = estado_esperar_Cliente;   // vai para o estado "esperar Cliente".
		}
		else   // se a Lista de Clientes Bluetooth NAO e' valida:
		{
			ESTADO_CLIENTE_BT = estado_resetar_Lista;   // vai para o estado "resetar Lista".
		}
	}

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_resetar_Lista )   // se esta' no estado "resetar Lista":
	{
		BT_Client_list_RESET();   // reseta a Lista de Clientes Bluetooth.

		DEBUG_start();  // inicia bloco de Debug.
		Serial.println();
		Serial.println( F("resetou Lista BT !!!") );
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.

		ESTADO_CLIENTE_BT = estado_esperar_Cliente;   // vai para o estado "esperar Cliente".
	}

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_esperar_Cliente )   // se esta' no estado "esperar Cliente":
	{
		if ( evento_externo == evento_conectou_BT )   // se um Cliente Bluetooth se conectou:
		{
			evento_externo = evento_nenhum;   // reseta indicador de evento.

			ESTADO_CLIENTE_BT = estado_verificar_Cliente;   // vai para o estado "verificar Cliente".
		}
	}

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_verificar_Cliente )   // se esta' no estado "verificar Cliente":
	{
		BT_Client_PIN_null_SET( &Client_PIN );   // anula o numero "PIN" atual.

		System_SPP.Client_PIN_get( &Client_PIN );   // obtem o "PIN" do Cliente atual.

		if ( !BT_Client_PIN_null_CHECK( &Client_PIN ) )   // se o "PIN" do Cliente nao e' nulo:
		{
			if ( BT_Client_list_SEARCH( Client_PIN ) != 0 )   // se este "PIN" esta' na Lista de Clientes:
			{
				envia_MSG_Cliente_na_Lista_BT();   // informa o Cliente que ele tem acesso permitido.

				DEBUG_start();  // inicia bloco de Debug.
				Serial.println();
				Serial.println( F("Cliente na Lista BT.") );
				Serial.println();
				DEBUG_end();   // finaliza bloco de Debug.

				evento_externo = evento_Cliente_Aut_BT;   // gera evento indicando que o Cliente autenticou.

				ESTADO_CLIENTE_BT = estado_esperar_Cliente;   // vai para o estado "esperar Cliente".
			}
			else   // se o "PIN" NAO esta' na Lista de Clientes:
			{
				DEBUG_start();  // inicia bloco de Debug.
				Serial.println();
				Serial.println( F("esperando Cliente BT autenticar...") );
				Serial.println();
				DEBUG_end();   // finaliza bloco de Debug.

				evento_Cliente = evento_req_senha_BT;   // gera evento requisitando senha de Autenticacao.

				ESTADO_CLIENTE_BT = estado_autenticar_Cliente;   // vai para o estado "autenticar Cliente".
			}
		}
		else   // se o "PIN" do Cliente e' nulo (falha interna ou "trambique"):
		{
			ESTADO_CLIENTE_BT = estado_esperar_Cliente;   // vai para o estado "esperar Cliente".
		}
	}

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_autenticar_Cliente )   // se esta' no estado "autenticar Cliente":
	{
		if ( evento_externo != evento_desconectou_BT )   // se o Cliente Bluetooth continua conectado:
		{
			evento_Cliente = MAQUINA_Autenticar_BT( evento_Cliente );   // obtem status da Autenticacao.

			if ( evento_Cliente == evento_Cliente_Aut_BT )   // se o Cliente autenticou:
			{
				DEBUG_start();  // inicia bloco de Debug.
				Serial.println();
				Serial.println( F("Cliente BT autenticou.") );
				Serial.println();
				DEBUG_end();   // finaliza bloco de Debug.

				ESTADO_CLIENTE_BT = estado_registrar_Cliente;   // vai para o estado "registrar Cliente".
			}
			else if ( evento_Cliente == evento_Cliente_NoAut_BT )   // se o Cliente NAO autenticou:
			{
				envia_MSG_intervalo_Autentic_BT();   // informa ao Cliente BT para esperar ate' nova tentativa.

				DEBUG_start();  // inicia bloco de Debug.
				Serial.println();
				Serial.println( F("Cliente BT nao autenticou !!!") );
				Serial.println();
				DEBUG_end();   // finaliza bloco de Debug.

				evento_externo = evento_Cliente_NoAut_BT;   // gera evento indicando que o Cliente NAO autenticou.

				ref_Tempo = millis();   // inicia contagem do intervalo de tempo ate' a proxima Autenticacao.

				ESTADO_CLIENTE_BT = estado_intervalo_Autentic;   // vai para o estado "intervalo de Autenticacao".
			}
		}
		else   // se o Cliente Bluetooth desconectou:
		{
			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("Cliente BT nao autenticou !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.

			MAQUINA_Autenticar_BT( evento_desconectou_BT );   // informa a "Maquina Autenticar" que o Cliente desconectou.

			evento_externo = evento_Cliente_NoAut_BT;   // gera evento indicando que o Cliente NAO autenticou.

			ref_Tempo = millis();   // inicia contagem do intervalo de tempo ate' a proxima Autenticacao.

			ESTADO_CLIENTE_BT = estado_intervalo_Autentic;   // vai para o estado "intervalo de Autenticacao".
		}
	}

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_intervalo_Autentic )   // se esta' no estado "intervalo de Autenticacao":
	{
		if ( ( millis() - ref_Tempo ) >= intervalo_Autentic_BT )   // se acabou o intervalo:
		{
			evento_externo = evento_nenhum;   // descarta qualquer evento recebido.

			ESTADO_CLIENTE_BT = estado_esperar_Cliente;   // vai para o estado "esperar Cliente".
		}
	}

//..................................................

	if ( ESTADO_CLIENTE_BT == estado_registrar_Cliente )   // se esta' no estado "registrar Cliente":
	{
		BT_Client_list_INSERT( Client_PIN );   // registra na Lista de Clientes, este novo Cliente Bluetooth.

		evento_externo = evento_Cliente_Aut_BT;   // gera evento indicando que o Cliente autenticou.

		ESTADO_CLIENTE_BT = estado_esperar_Cliente;   // vai para o estado "esperar Cliente".
	}

//..................................................

	return ( evento_externo );   // informa se ocorreu algum evento.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Gerenciamento da Maquina de Estados que controle a Conexao
//	Bluetooth deste Sistema (PCOM Bluetooth).
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao do timeout default para espera da Configuracao
//	Bluetooth e da conexao de um Cliente Bluetooth. Neste
//	setting, o periodo de timeout e' especificado em segundos.
//=======================================================================

#define	BT_timeout_DEF   10   // default para o timeout, em segundos.

//***********************************************************************




//***********************************************************************
//	Variavel para armazenar o periodo do "BT timeout". O valor
//	desta veriavel estara' sempre em unidades de mili-segundos.
//=======================================================================

unsigned long BT_timeout = em_segundos( BT_timeout_DEF );

//***********************************************************************




//***********************************************************************
//	Gerencia o timeout para espera da Configuracao Bluetooth e
//	da conexao de um Cliente Bluetooth. E' possivel resetar a
//	contagem de timeout, ou entao verificar se ocorreu o timeout.
//=======================================================================

bool	BT_timeout_MANAGER ( bool reset )
{
//--------------------------------------------------
bool timeout = false;
static unsigned long ref_Tempo = 0;
unsigned long tempo;
//--------------------------------------------------

	if ( reset )   // se o timeout deve ser resetado:
	{
		ref_Tempo = millis();	// reseta a contagem de timeout.
	}
	else   // se o timeout esta' sendo verificado:
	{
		tempo = millis();   // obtem a contagem de tempo atual.

		if ( ( tempo - ref_Tempo ) >= BT_timeout )  // se ocorreu timeout:
		{
			timeout = true;   // indica que ocorreu o timeout.
		}
	}

	return ( timeout );   // finaliza, indicando se ocorreu timeout.
}
//***********************************************************************




//***********************************************************************
//	Reseta a contagem de timeout para espera da Configuracao
//	Bluetooth e da conexao de um Cliente Bluetooth.
//=======================================================================

void	BT_timeout_RESET ()
{
	BT_timeout_MANAGER( true );   // reseta a contagem de timeout.
}
//***********************************************************************




//***********************************************************************
//	Verifica se ocorreu timeout para espera da Configuracao
//	Bluetooth e da conexao de um Cliente Bluetooth.
//=======================================================================

bool	BT_timeout_Check ()
{
	return ( BT_timeout_MANAGER( false ) );   // retorna o resultado.
}
//***********************************************************************




//***********************************************************************
//	Executa as operacoes necessarias para abrir uma conexao
//	Bluetooth SPP. Se uma conexao SPP ja' foi iniciada, entao
//	esta conexao e' desconfigurada, para permitir uma nova
//	inicializacao. Entao a inicializacao do SPP e' feita, sendo
//	especificado o nome do dispositivo Bluetooth deste Sistema.
//=======================================================================

bool	inicia_conexao_BT ()
{
//--------------------------------------------------
static bool SPP_started = false;
bool Ok;
//--------------------------------------------------

	if ( SPP_started )  // se o SPP foi inicializado anteriormente:
	{
		System_SPP.BTC_deinit();   // entao desconfigura o SPP.
	}

	Ok = System_SPP.begin( nome_BLUETOOTH );   // inicializa o SPP.

	SPP_started = true;   // registra que inicializou o SPP.

	if ( Ok )   // se teve sucesso na inicializacao:
	{
		System_SPP.flush();   // esvazia o Buffer de envio pelo SPP.
	}

	return ( Ok );   // informa o resultado da inicializacao.
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que o Bluetooth foi desconectado.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_BT_desconectado ()
{
	Serial.println();
	Serial.println( F("Bluetooth desconectado !!!") );
	Serial.println();
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que o Bluetooth foi conectado.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_BT_conectado ()
{
	Serial.println();
	Serial.println( F("Bluetooth conectado !!!") );
	Serial.println();
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que ocorreu timeout na espera da
//	Configuracao Bluetooth ou da conexao de um Cliente Bluetooth.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_BT_timeout ()
{
	Serial.println();
	Serial.println( F("timeout Bluetooth !!!") );
	Serial.println();
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que esta' esperando um Cliente
//	Bluetooth (e eventual pareamento).
//	A funcao e' temporizada, para exibir o aviso a intervalos de
//	tempo definidos no codigo.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_esperando_Cliente_BT ()
{
//--------------------------------------------------
static unsigned long ref_Tempo = 0;
unsigned long tempo;
//--------------------------------------------------

	tempo = millis();   // obtem a contagem de tempo atual.

	if ( ( tempo - ref_Tempo ) >= 2000 )   // se e' o momento:
	{
		Serial.println( F("esperando pareamento Bluetooth ...") );   // exibe a mensagem.
		Serial.println();

		ref_Tempo = tempo;   // nova referencia de tempo para exibicao.
	}
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que esta' esperando sucesso na
//	Configuracao Bluetooth.
//	A funcao e' temporizada, para exibir o aviso a intervalos de
//	tempo definidos no codigo.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_setup_BT ()
{
//--------------------------------------------------
static unsigned long ref_Tempo = 0;
unsigned long tempo;
//--------------------------------------------------

	tempo = millis();   // obtem a contagem de tempo atual.

	if ( ( tempo - ref_Tempo ) >= 1000 )   // se e' o momento:
	{
		Serial.println( F("setup Bluetooth ...") );   // exibe a mensagem.

		ref_Tempo = tempo;   // nova referencia de tempo para exibicao.
	}
}
//***********************************************************************




//***********************************************************************
//	Definicao dos estados da Maquina de Estados que gerencia a
//	Conexao Bluetooth:
//=======================================================================

enum	// estados da Conexao Bluetooth:
{
	estado_BT_inicio,	// estado para configuracoes iniciais.

	estado_BT_setup,	// estado para configuracao do Bluetooth.

	estado_BT_esperando,	// estado aguardando um Cliente Bluetooth.

	estado_BT_conectado,	// estado quando um Cliente Bluetooth esta' conectado.
};
//***********************************************************************




//***********************************************************************
//	Implementacao da Maquina de Estados que gerencia a Conexao
//	Bluetooth do Sistema.
//=======================================================================

byte	MAQUINA_gerencia_Bluetooth ( byte evento_externo )
{
//--------------------------------------------------
static byte ESTADO_BT = estado_BT_inicio;
bool Ok;
//--------------------------------------------------

//..................................................

	if ( ESTADO_BT == estado_BT_inicio )   // se esta' no estado "inicio":
	{
		if ( evento_externo == evento_conectar_BT )  // se deve conectar o Bluetooth:
		{
			evento_externo = evento_nenhum;   // reseta indicador de evento.

			BT_timeout_RESET();   // reseta o timeout de espera pelo Bluetooth.

			ESTADO_BT = estado_BT_setup;   // vai para o estado "setup".
		}
		else   // se nao deve conectar agora, indica um timeout imediato:
		{
			evento_externo = evento_timeout_BT;   // gera Evento indicando o timeout.
		}
	}

//..................................................

	if ( ESTADO_BT == estado_BT_setup )   // se esta' no estado "setup":
	{
		DEBUG_line( exibe_setup_BT() );   // informa via Debug.

		Ok = inicia_conexao_BT();   // inicializa a conexao Bluetooth SPP.

		if ( Ok )   // se teve sucesso na inicializacao:
		{
			BT_timeout_RESET();   // reseta o timeout de espera pelo Bluetooth.

			ESTADO_BT = estado_BT_esperando;   // vai para o estado "esperando".
		}
		else if ( BT_timeout_Check() )   // se falhou e ocorreu timeout:
		{
			DEBUG_line( exibe_BT_timeout() );   // informa via Debug.

			evento_externo = evento_timeout_BT;   // gera Evento indicando o timeout.

			ESTADO_BT = estado_BT_inicio;   // vai para o estado "inicio".
		}
	}

//..................................................

	if ( ESTADO_BT == estado_BT_esperando )   // se esta' no estado "esperando":
	{
		DEBUG_line( exibe_esperando_Cliente_BT() );   // informa via Debug.

		Ok = System_SPP.hasClient();   // verifica se algum Cliente conectou.

		if ( Ok )   // se algum Cliente conectou: 
		{
			DEBUG_line( exibe_BT_conectado() );   // informa via Debug.

			evento_externo = evento_conectou_BT;   // gera Evento indicando que conectou.

			ESTADO_BT = estado_BT_conectado;   // vai para o estado "conectado".
		}
		else if ( BT_timeout_Check() )   // se nao conectou e ocorreu timeout:
		{
			DEBUG_line( exibe_BT_timeout() );   // informa via Debug.

			evento_externo = evento_timeout_BT;   // gera Evento indicando o timeout.

			ESTADO_BT = estado_BT_inicio;   // vai para o estado "inicio".
		}
	}

//..................................................

	if ( ESTADO_BT == estado_BT_conectado )   // se esta' no estado "conectado":
	{
		Ok = System_SPP.hasClient();   // verifica se o Cliente esta' conectado.

		if ( !Ok || ( evento_externo == evento_desconectar_BT ) )   // se deve interromper o Bluetooth:
		{
			System_SPP.disconnect();   // garante Cliente desconectado.

			DEBUG_line( exibe_BT_desconectado() );   // informa via Debug.

			evento_externo = evento_desconectou_BT;   // gera Evento indicando que desconectou.

			ESTADO_BT = estado_BT_inicio;   // vai para o estado "inicio".
		}
	}

//..................................................

	return ( evento_externo );   // informa se ocorreu algum evento.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Gerenciamento da Maquina de Estados que controle a Conexao
//	WiFi deste Sistema (PCOM WiFi).
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Definicao e instanciamento do WiFi Server, para atender as
//	requisicoes da Interface de Controle do Sistema, via uma
//	Porta TCP/IP definida:
//=======================================================================

WiFiServer  System_WiFi_server( WiFi_SERVER_PORT );  // instancia o WiFi Server.

//***********************************************************************




//***********************************************************************
//	Definicao do timeout default para espera do estabelecimento
//	de uma Conexao WiFi. Neste setting, o periodo de timeout e'
//	especificado em segundos.
//=======================================================================

#define	WiFi_timeout_DEF   7   // timeout default, em segundos.

//***********************************************************************




//***********************************************************************
//	Variavel para armazenar o periodo do "WiFi timeout". O valor
//	desta veriavel estara' sempre em unidades de mili-segundos.
//=======================================================================

unsigned long WiFi_timeout = em_segundos( WiFi_timeout_DEF );

//***********************************************************************




//***********************************************************************
//	Gerencia o timeout da espera da Conexao WiFi. E' possivel
//	resetar a contagem de timeout, ou entao verificar se ocorreu
//	o timeout.
//=======================================================================

bool	WiFi_timeout_MANAGER ( bool reset )
{
//--------------------------------------------------
bool timeout = false;
static unsigned long ref_Tempo = 0;
unsigned long tempo;
//--------------------------------------------------

	if ( reset )   // se o timeout deve ser resetado:
	{
		ref_Tempo = millis();	// reseta a contagem de timeout.
	}
	else   // se o timeout esta' sendo verificado:
	{
		tempo = millis();   // obtem a contagem de tempo atual.

		if ( ( tempo - ref_Tempo ) >= WiFi_timeout )  // se ocorreu timeout:
		{
			timeout = true;   // indica que ocorreu o timeout.
		}
	}

	return ( timeout );   // finaliza, indicando se ocorreu timeout.
}
//***********************************************************************




//***********************************************************************
//	Reseta a contagem de timeout da espera da Conexao WiFi.
//=======================================================================

void	WiFi_timeout_RESET ()
{
	WiFi_timeout_MANAGER( true );	// reseta a contagem de timeout.
}
//***********************************************************************




//***********************************************************************
//	Verifica se ocorreu timeout na espera da Conexao WiFi.
//=======================================================================

bool	WiFi_timeout_Check ()
{
	return ( WiFi_timeout_MANAGER( false ) );   // retorna o resultado.
}
//***********************************************************************




//***********************************************************************
//	Executa as operacoes necessarias para fechar a conexao WiFi
//	atual, e manter a mesma fechada ate' nova ordem de reconexao.
//=======================================================================

void	fecha_conexao_WiFi ()
{
	WiFi.setAutoReconnect ( false );   // desabilita o "Auto-Reconnect".

	WiFi.disconnect( true, false );   // "desliga" o WiFi ( wifioff, eraseap ).
}
//***********************************************************************




//***********************************************************************
//	Executa as operacoes necessarias para abrir a conexao WiFi.
//	Se uma conexao WiFi ainda nao foi iniciada, o nome da Rede
//	e a respectiva senha sao setadas. Se uma conexao WiFi ja'
//	foi iniciada anteriormente, entao apemas uma reconexao e'
//	executada.
//=======================================================================

void	inicia_conexao_WiFi ()
{
//--------------------------------------------------
static bool WF_started = false;
//--------------------------------------------------

	if ( !WF_started )   // se nao inicializou o WiFi:
	{
		WiFi.begin( WiFi_ssid.c_str(), WiFi_password.c_str() );  // inicializa o WiFi.

		WF_started = true;   // registra que inicializou o WiFi.
	}
	else	// se ja' inicializou o WiFi:
	{
		WiFi.enableSTA( true );   // garante modo "Station" habilitado.

		WiFi.setAutoReconnect ( true );   // habilita o "Auto-Reconnect".

		WiFi.reconnect();   // faz um "Reconnect".
	}
}
//***********************************************************************




//***********************************************************************
//	Executa as operacoes necessarias a fim de inicializar o
//	"WiFi Server".
//=======================================================================

void	inicia_Server_WiFi ()
{
//--------------------------------------------------
static bool SVR_started = false;
//--------------------------------------------------

	if ( !SVR_started )   // se nao inicializou o "WiFi Server":
	{
		System_WiFi_server.begin( WiFi_SERVER_PORT );   // inicializa o "WiFi Server".

		SVR_started = true;   // registra que inicializou o "WiFi Server".
	}
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que o WiFi foi conectado, sendo
//	informado o nome da Rede e o Endereco IP da conexao.
//=======================================================================

void	exibe_WiFi_conectado ()
{
	Serial.println();
	Serial.println( F("WiFi conectado !!!") );
	Serial.print( F("Rede: ") );
	Serial.println( WiFi_ssid );
	Serial.print( F("endereco IP = ") );
	Serial.println( WiFi.localIP() );
	Serial.println();
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que o WiFi foi desconectado.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_WiFi_desconectado ()
{
	Serial.println();
	Serial.println( F("WiFi desconectado !!!") );
	Serial.println();
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que ocorreu timeout na espera da
//	Conexao WiFi.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_WiFi_timeout ()
{
	Serial.println();
	Serial.println( F("timeout WiFi !!!") );
	Serial.println();
}
//***********************************************************************




//***********************************************************************
//	Avisa via Terminal Serial, que esta' esperando a Conexao WiFi.
//	A funcao e' temporizada, para exibir o aviso a intervalos de
//	tempo definidos no codigo.
//	Funcao normalmente usada apenas no desenvolvimento do Sistema,
//	para efeito de depuracao.
//=======================================================================

void	exibe_esperando_WiFi ()
{
//--------------------------------------------------
static unsigned long ref_Tempo = 0;
unsigned long tempo;
//--------------------------------------------------

	tempo = millis();   // obtem a contagem de tempo atual.

	if ( ( tempo - ref_Tempo ) >= 2000 )   // se e' o momento:
	{
		Serial.println( F("esperando Rede WiFi ...") );   // exibe a mensagem.
		Serial.println();

		ref_Tempo = tempo;   // nova referencia de tempo para exibicao.
	}
}
//***********************************************************************




//***********************************************************************
//	Definicao dos estados da Maquina de Estados que gerencia a
//	Conexao WiFi:
//=======================================================================

enum	// estados da Conexao WiFi:
{
	estado_WF_inicio,	// estado inicial.

	estado_WF_setup,	// estado para configuracao da Conexao WiFi.

	estado_WF_esperando,	// estado aguardando uma Conexao WiFi.

	estado_WF_SERVER_init,	// estado para inicializacao do WiFi Server.

	estado_WF_conectado,	// estado quando o WiFi esta' conectado.
};
//***********************************************************************




//***********************************************************************
//	Implementacao da Maquina de Estados que gerencia a Conexao
//	WiFi do Sistema.
//=======================================================================

byte	MAQUINA_gerencia_WiFi ( byte evento_externo )
{
//--------------------------------------------------
static byte ESTADO_WF = estado_WF_inicio;
bool Ok;
//--------------------------------------------------

//..................................................

	if ( ESTADO_WF == estado_WF_inicio )   // se esta' no estado "inicio":
	{
		if ( evento_externo == evento_conectar_WF )  // se deve conectar o WiFi:
		{
			evento_externo = evento_nenhum;   // reseta indicador de evento.

			ESTADO_WF = estado_WF_setup;   // vai para o estado "setup".
		}
		else   // se nao deve conectar agora, indica um timeout imediato:
		{
			evento_externo = evento_timeout_WF;   // gera Evento indicando o timeout.
		}
	}

//..................................................

	if ( ESTADO_WF == estado_WF_setup )   // se esta' no estado "setup":
	{
		inicia_conexao_WiFi();   // inicia a conexao do WiFi.

		WiFi_timeout_RESET();	// reseta o timeout de espera da Conexao WiFi.

		ESTADO_WF = estado_WF_esperando;   // vai para o estado "esperando".
	}

//..................................................

	if ( ESTADO_WF == estado_WF_esperando )   // se esta' no estado "esperando":
	{
		DEBUG_line( exibe_esperando_WiFi() );   // informa via Debug.

		if ( !WiFi_timeout_Check() )	// se nao ocorreu timeout na espera:
		{
			if ( WiFi.status() == WL_CONNECTED )   // se o WiFi conectou:
			{
				ESTADO_WF = estado_WF_SERVER_init;   // vai para o estado "Server init".
			}
		}
		else	// se ocorreu timeout na espera:
		{
			DEBUG_line( exibe_WiFi_timeout() );   // informa via Debug.

			fecha_conexao_WiFi();   // finaliza tentativa atual de conexao.

			evento_externo = evento_timeout_WF;   // gera Evento indicando o timeout.

			ESTADO_WF = estado_WF_inicio;   // vai para o estado "inicio".
		}
	}

//..................................................

	if ( ESTADO_WF == estado_WF_SERVER_init )   // se esta' no estado "Server init":
	{
		inicia_Server_WiFi();   // inicializa o "WiFi Server".

		exibe_WiFi_conectado();   // informa via Terminal Serial que o WiFi esta' conectado.

		evento_externo = evento_conectou_WF;   // gera Evento indicando que conectou via WiFi.

		ESTADO_WF = estado_WF_conectado;   // vai para o estado "conectado".
	}

//..................................................

	if ( ESTADO_WF == estado_WF_conectado )   // se esta' no estado "conectado":
	{
		Ok = ( WiFi.status() == WL_CONNECTED );   // verifica se o WiFi continua conectado.

		if ( !Ok || ( evento_externo == evento_desconectar_WF ) )   // se desconectou, ou se deve desconectar:
		{
			fecha_conexao_WiFi();   // finaliza a conexao atual.

			DEBUG_line( exibe_WiFi_desconectado() );   // informa via Debug.

			evento_externo = evento_desconectou_WF;   // gera Evento indicando que desconectou o WiFi.

			ESTADO_WF = estado_WF_inicio;   // vai para o estado "inicio".
		}
	}

//..................................................

	return ( evento_externo );   // informa se ocorreu algum evento.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Gerenciamento da Maquina de Estados que controla a Conexao
//	atual deste Sistema (o PCOM atualmente disponivel).
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Enumeracao dos Ports de Comunicacao (PCOM) possiveis de serem
//	utilizados neste Sistema:
//=======================================================================

enum	// PCOMs deste Sistema:
{
	PCOM_nenhum,	// indica nenhum PCOM.

	PCOM_WiFi,	// identificacao do PCOM WiFi.

	PCOM_BTC,	// identificacao do PCOM Bluetooth Classic (BTC).
};
//***********************************************************************




//***********************************************************************
//	Definicao da Variavel que indica qual PCOM atualmente esta'
//	conectado para comunicacao com este Sistema:
//=======================================================================

byte	PCOM_atual = PCOM_nenhum;   // indica o PCOM atual conectado.

//***********************************************************************




//***********************************************************************
//	Definicao das Flags que controlam a permissao de conexao via
//	PCOMs WiFi e Bluetooth:
//=======================================================================

bool	PCOM_WiFi_allow = true;  // controla permissao de uso do PCOM WiFi.

bool	PCOM_BTC_allow = true;  // controla permissao de uso do PCOM BTC.

//***********************************************************************




//***********************************************************************
//	Definicao das Variaveis que indicam se um Cliente fez uma
//	Autenticacao valida neste Sistema, via PCOM especifico:
//=======================================================================

bool	PCOM_WiFi_pass = false;   // indica se um Cliente Autenticou no WiFi.

bool	PCOM_BTC_pass = false;   // indica se um Cliente Autenticou no BTC.

//***********************************************************************




//***********************************************************************
//	Funcao para verificar se deve desabilitar ou reabilitar o
//	PCOM WiFi, via comando enviado para debug/testes. Para tal, se
//	um comando e' identificado, a funcao emite ou mascara Eventos
//	do Sistema, a fim de habilitar ou desabilitar o PCOM.
//	Para desabilitar o PCOM WiFi, e' necessario que o mesmo esteja
//	atualmente conectado. E para habilitar, e' necessario que o
//	PCOM WiFi esteja desconectado.
//	Na saida, a funcao informa se algum comando foi executado.
//	Normalmente, esta funcao e' utilizada apenas em testes de Debug
//	ou desenvolvimento do Sistema.
//=======================================================================

bool	PCOM_WiFi_ON_OFF_CMD_check ( char CMD_char )
{
//--------------------------------------------------
static bool WF_EN = true;
bool CMD = false;
//--------------------------------------------------

	if ( ( PCOM_atual == PCOM_WiFi ) && ( evento_Gerencia_WiFi == evento_nenhum ) )  // se PCOM WiFi ativo e sem eventos:
	{
		if ( ( CMD_char == 'x' ) && WF_EN )  // se deve desabilitar o PCOM WiFi:
		{
			WF_EN = false;   // registra esta condicao.

			Serial.println();
			Serial.println( F("desabilitou WiFi !!!") );   // informa via Terminal.
			Serial.println();

			evento_Gerencia_WiFi = evento_desconectar_WF;  // gera evento para desconectar o PCOM WiFi.

			CMD = true;   // indica que recebeu comando via Debug.
		}
	}
	else if ( ( PCOM_atual == PCOM_nenhum ) && ( evento_Gerencia_WiFi == evento_conectar_WF ) )  // sem PCOM ativo, e com evento "conectar WiFi":
	{
		if ( ( CMD_char == 'w' ) && !WF_EN )  // se deve habilitar o PCOM WiFi:
		{
			WF_EN = true;   // registra esta condicao.

			Serial.println();
			Serial.println( F("habilitou WiFi !!!") );   // informa via Terminal.
			Serial.println();

			CMD = true;   // indica que recebeu comando via Debug.
		}

		if ( !WF_EN )  evento_Gerencia_WiFi = evento_nenhum;  // se WiFi ainda inativo, impede evento "conectar WiFi".
	}

	return ( CMD );   // informa se recebeu algum comando.
}
//***********************************************************************




//***********************************************************************
//	Funcao para verificar se e' permitido fazer conexao atraves
//	do PCOM WiFi.
//	A permissao e' controlada por uma Flag ON/OFF, que pode ser
//	alterada a qualquer momento no Sistema (ou seja, e' do tipo
//	"on the fly"). Para isto, a funcao emite ou mascara Eventos
//	conforme o estado da Flag de permissao.
//	Se a Flag indica que a conexao e' permitida, entao a funcao
//	tambem verifica se foi enviado algum comando via Debug para
//	controlar a conexao do PCOM WiFi (informando na saida, se
//	algum comando foi executado).
//=======================================================================

bool	PCOM_WiFi_allow_check ( char CMD_char )
{
//--------------------------------------------------
static bool WF_EN = true;
bool CMD = false;
//--------------------------------------------------

	if ( !PCOM_WiFi_allow )   // se o PCOM WiFi nao e' permitido:
	{
		if ( ( PCOM_atual == PCOM_WiFi ) && ( evento_Gerencia_WiFi == evento_nenhum ) )  // se PCOM WiFi ativo e sem eventos:
		{
			evento_Gerencia_WiFi = evento_desconectar_WF;  // gera evento para desconectar o PCOM WiFi.
		}
		else if ( ( PCOM_atual == PCOM_nenhum ) && ( evento_Gerencia_WiFi == evento_conectar_WF ) )  // sem PCOM ativo, e com evento "conectar WiFi":
		{
			evento_Gerencia_WiFi = evento_nenhum;  // impede evento "conectar WiFi".
		}

		if ( WF_EN )   // se nao sinalizou a ocorrencia:
		{
			WF_EN = false;   // registra que sinalizou.

			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("nao permitido PCOM WiFi !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}
	else   // se o PCOM WiFi e' permitido:
	{
		DEBUG_line( CMD = PCOM_WiFi_ON_OFF_CMD_check( CMD_char ) );  // verifica se deve habilitar/desabilitar o PCOM WiFi, via Debug.

		if ( !WF_EN && !CMD)   // se nao sinalizou a ocorrencia, nem recebeu comando via Debug:
		{
			WF_EN = true;   // registra que sinalizou.

			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("permitido PCOM WiFi !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}

	return ( CMD );   // informa se recebeu algum comando.
}
//***********************************************************************




//***********************************************************************
//	Funcao para verificar se deve desabilitar ou reabilitar o
//	PCOM Bluetooth, via comando enviado para debug/testes. Para
//	tal, se um comando e' identificado, a funcao emite ou mascara
//	Eventos do Sistema, a fim de habilitar ou desabilitar o PCOM.
//	Para desabilitar o PCOM Bluetooth, e' necessario que o mesmo
//	esteja atualmente conectado. E para habilitar, e' necessario
//	que o PCOM Bluetooth esteja desconectado.
//	Na saida, a funcao informa se algum comando foi executado.
//	Normalmente, esta funcao e' utilizada apenas em testes de Debug
//	ou desenvolvimento do Sistema.
//=======================================================================

bool	PCOM_BTC_ON_OFF_CMD_check ( char CMD_char )
{
//--------------------------------------------------
static bool BT_EN = true;
bool CMD = false;
//--------------------------------------------------

	if ( ( PCOM_atual == PCOM_BTC ) && ( evento_Gerencia_BT == evento_nenhum ) )  // se PCOM Bluetooth ativo e sem eventos:
	{
		if ( ( CMD_char == 'y' ) && BT_EN )  // se deve desabilitar o PCOM Bluetooth:
		{
			BT_EN = false;   // registra esta condicao.

			Serial.println();
			Serial.println( F("desabilitou Bluetooth !!!") );   // informa via Terminal.
			Serial.println();

			evento_Gerencia_BT = evento_desconectar_BT;  // gera evento para desconectar o PCOM Bluetooth.

			CMD = true;   // indica que recebeu comando via Debug.
		}
	}
	else if ( ( PCOM_atual == PCOM_nenhum ) && ( evento_Gerencia_BT == evento_conectar_BT ) )  // sem PCOM ativo, e com evento "conectar BT":
	{
		if ( ( CMD_char == 'b' ) && !BT_EN )  // se deve habilitar o PCOM Bluetooth:
		{
			BT_EN = true;   // registra esta condicao.

			Serial.println();
			Serial.println( F("habilitou Bluetooth !!!") );   // informa via Terminal.
			Serial.println();

			CMD = true;   // indica que recebeu comando via Debug.
		}

		if ( !BT_EN )  evento_Gerencia_BT = evento_nenhum;  // se Bluetooth ainda inativo, impede evento "conectar BT".
	}

	return ( CMD );   // informa se recebeu algum comando.
}
//***********************************************************************




//***********************************************************************
//	Funcao para verificar se e' permitido fazer conexao atraves
//	do PCOM Bluetooth.
//	A permissao e' controlada por uma Flag ON/OFF, que pode ser
//	alterada a qualquer momento no Sistema (ou seja, e' do tipo
//	"on the fly"). Para isto, a funcao emite ou mascara Eventos
//	conforme o estado da Flag de permissao.
//	Se a Flag indica que a conexao e' permitida, entao a funcao
//	tambem verifica se foi enviado algum comando via Debug para
//	controlar a conexao do PCOM BT (e informa na saida, se algum
//	comando foi executado).
//=======================================================================

bool	PCOM_BTC_allow_check ( char CMD_char )
{
//--------------------------------------------------
static bool BT_EN = true;
bool CMD = false;
//--------------------------------------------------

	if ( !PCOM_BTC_allow )   // se o PCOM Bluetooth nao e' permitido:
	{
		if ( ( PCOM_atual == PCOM_BTC ) && ( evento_Gerencia_BT == evento_nenhum ) )  // se PCOM BT ativo e sem eventos:
		{
			evento_Gerencia_BT = evento_desconectar_BT;  // gera evento para desconectar o PCOM Bluetooth.
		}
		else if ( ( PCOM_atual == PCOM_nenhum ) && ( evento_Gerencia_BT == evento_conectar_BT ) )  // sem PCOM ativo, e com evento "conectar BT":
		{
			evento_Gerencia_BT = evento_nenhum;  // impede evento "conectar Bluetooth".
		}

		if ( BT_EN )   // se nao sinalizou a ocorrencia:
		{
			BT_EN = false;   // registra que sinalizou.

			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("nao permitido PCOM BT !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}
	else   // se o PCOM Bluetooth e' permitido:
	{
		DEBUG_line( CMD = PCOM_BTC_ON_OFF_CMD_check( CMD_char ) );  // verifica se deve habilitar/desabilitar o PCOM BT, via Debug.

		if ( !BT_EN && !CMD)   // se nao sinalizou a ocorrencia, nem recebeu comando via Debug:
		{
			BT_EN = true;   // registra que sinalizou.

			DEBUG_start();  // inicia bloco de Debug.
			Serial.println();
			Serial.println( F("permitido PCOM BT !!!") );
			Serial.println();
			DEBUG_end();   // finaliza bloco de Debug.
		}
	}

	return ( CMD );   // informa se recebeu algum comando.
}
//***********************************************************************




//***********************************************************************
//	Funcao para verificar se e' permitido fazer conexao atraves
//	dos PCOMs WiFi e Bluetooth.
//	A permissao e' controlada por Flags ON/OFF, que podem ser
//	alteradas a qualquer momento no Sistema (ou seja, sao do tipo
//	"on the fly"). Para isto, a funcao emite ou mascara Eventos
//	conforme o estado das Flags de permissao, e se o PCOM esta'
//	atualmente conectado ou nao.
//	Se uma Flag indica que uma determinada conexao e' permitida,
//	entao tambem e' verificado se foi enviado algum comando via
//	Debug para controlar o respectivo PCOM.
//=======================================================================

void	PCOM_allow_check ()
{
//--------------------------------------------------
static char CMD_char = 0;
char c;
bool CMD;
//--------------------------------------------------

	DEBUG_start();  // inicia bloco de Debug.

	while ( Serial.available() )  // se foi enviado algum caracter via Serial:
	{
		c = Serial.read();   // le este caracter.

		if ( c >= 0x20 )  CMD_char = c;  // considera se possivel comando do Debug.
	}

	DEBUG_end();   // finaliza bloco de Debug.

//..................................................

	CMD = PCOM_WiFi_allow_check( CMD_char );  // verifica permissao de uso do PCOM WiFi.

	if ( CMD )  CMD_char = 0;  // descarta comando do Debug, se este foi executado.

//..................................................

	CMD = PCOM_BTC_allow_check( CMD_char );   // verifica permissao de uso do PCOM BTC.

	if ( CMD )  CMD_char = 0;  // descarta comando do Debug, se este foi executado.
}
//***********************************************************************




//***********************************************************************
//	Definicao dos estados da Maquina de Estados que gerencia a
//	Conexao atual deste Sistema:
//=======================================================================

enum	// estados da conexao atual deste Sistema:
{
	estado_SYS_inicio,	// estado inicial deste Sistema, sem PCOM ativo.

	estado_SYS_espera_WF,	// estado para esperar configuracao e conexao do PCOM WiFi.

	estado_SYS_PCOM_WF,	// estado onde o PCOM WiFi esta' ativo.

	estado_SYS_espera_BT,	// estado para esperar configuracao e conexao do PCOM Bluetooth.

	estado_SYS_PCOM_BT,	// estado onde o PCOM Bluetooth esta' ativo.

	estado_SYS_permitir_BT,	// estado para habilitar fluxo de dados via PCOM Bluetooth.

	estado_SYS_bloquear_BT,	// estado para desabilitar fluxo de dados via PCOM Bluetooth.
};
//***********************************************************************




//***********************************************************************
//	Funcao para exibir no Terminal Serial do Arduino, o estado
//	atual da Maquina de Estados que gerencia a Conexao deste
//	Sistema.
//	A exibicao e' temporizada com um numero irracional (no caso,
//	o numero neperiano "e"), de forma a impedir que a amostragem
//	se fixe em um determinado estado (isto tambem impede que uma
//	grande quantidade de dados seja despejada via Serial).
//	Devido a esta temporizacao, muito dificilmente serao exibidos
//	os estados temporarios.
//	A funcao e' normalmente usada em testes de desenvolvimento
//	ou Debug do Sistema.
//=======================================================================

void	SYS_STATUS_view ( byte estado_atual )
{
//--------------------------------------------------
static unsigned long ref_Tempo = 0;
//--------------------------------------------------

	if ( ( millis() - ref_Tempo ) >= 2718 )	// se e' o momento de exibir:
	{
		Serial.print( F("estado = ") );

		switch ( estado_atual )   // exibe conforme o estado atual:
		{
			case estado_SYS_espera_WF: Serial.println( F("esperando PCOM WF") );   break;

			case estado_SYS_PCOM_WF: Serial.println( F("PCOM WF ativo") );  break;

			case estado_SYS_espera_BT: Serial.println( F("esperando PCOM BT") );   break;

			case estado_SYS_PCOM_BT: Serial.println( F("PCOM BT ativo") );  break;

			default: Serial.println( F("estado temporario...") );
		}

		ref_Tempo = millis();   // nova referencia de tempo para exibicao.
	}
}
//***********************************************************************




//***********************************************************************
//	Implementacao da Maquina de Estados que gerencia a Conexao
//	atual deste Sistema.
//=======================================================================

void	MAQUINA_gerencia_CONEXAO ()
{
//--------------------------------------------------
static byte ESTADO_CONEXAO = estado_SYS_inicio;
//--------------------------------------------------

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_inicio )  // se esta' no estado "inicio":
	{
		PCOM_atual = PCOM_nenhum;   // registra que nao ha' PCOM ativo.

		PCOM_WiFi_pass = false;   // invalida Autenticacao do PCOM WiFi.

		PCOM_BTC_pass = false;   // invalida Autenticacao do PCOM Bluetooth.

		evento_Gerencia_WiFi = evento_conectar_WF;  // gera evento para iniciar via PCOM WiFi.

		ESTADO_CONEXAO = estado_SYS_espera_WF;   // vai para o estado "esperando PCOM WiFi".
	}

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_espera_WF )   // se esta' no estado "esperando PCOM WiFi":
	{
		if ( evento_Gerencia_WiFi == evento_conectou_WF )   // se o PCOM WiFi conectou:
		{
			evento_Gerencia_WiFi = evento_nenhum;  // reseta indicador de evento.

			PCOM_atual = PCOM_WiFi;   // registra que o PCOM WiFi esta' ativo.

			PCOM_WiFi_pass = true;   // registra que o PCOM WiFi esta' Autenticado.

			ESTADO_CONEXAO = estado_SYS_PCOM_WF;   // vai para o estado "PCOM WiFi ativo".
		}
		else if ( evento_Gerencia_WiFi == evento_timeout_WF )  // se ocorreu timeout no PCOM WiFi:
		{
			evento_Gerencia_WiFi = evento_nenhum;  // reseta indicador de evento.

			evento_Gerencia_BT = evento_conectar_BT;  // gera evento para iniciar o PCOM Bluetooth.

			ESTADO_CONEXAO = estado_SYS_espera_BT;   // vai para o estado "esperando PCOM BT".
		}
	}

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_PCOM_WF )   // se esta' no estado "PCOM WiFi ativo":
	{
		if ( evento_Gerencia_WiFi == evento_desconectou_WF )   // se o PCOM WiFi desconectou:
		{
			evento_Gerencia_WiFi = evento_nenhum;  // reseta indicador de evento.

			PCOM_atual = PCOM_nenhum;   // registra que nao ha' PCOM ativo.

			PCOM_WiFi_pass = false;   // invalida Autenticacao do PCOM WiFi.

			evento_Gerencia_BT = evento_conectar_BT;  // gera evento para iniciar o PCOM Bluetooth.

			ESTADO_CONEXAO = estado_SYS_espera_BT;   // vai para o estado "esperando PCOM BT".
		}
	}

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_espera_BT )   // se esta' no estado "esperando PCOM BT":
	{
		if ( evento_Gerencia_BT == evento_conectou_BT )   // se o PCOM Bluetooth conectou:
		{
			evento_Gerencia_BT = evento_nenhum;   // reseta indicador de evento.

			PCOM_atual = PCOM_BTC;   // registra que o PCOM Bluetooth esta' ativo.

			evento_Cliente_BT = evento_conectou_BT;   // gera evento indicando que Cliente BT conectou.

			ESTADO_CONEXAO = estado_SYS_PCOM_BT;   // vai para o estado "PCOM BT ativo".
		}
		else if ( evento_Gerencia_BT == evento_timeout_BT )  // se ocorreu timeout no PCOM Bluetooth:
		{
			evento_Gerencia_BT = evento_nenhum;   // reseta indicador de evento.

			evento_Gerencia_WiFi = evento_conectar_WF;  // gera evento para iniciar o PCOM WiFi.

			ESTADO_CONEXAO = estado_SYS_espera_WF;   // vai para o estado "esperando PCOM WF".
		}
	}

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_PCOM_BT )   // se esta' no estado "PCOM BT ativo":
	{
		if ( evento_Gerencia_BT == evento_desconectou_BT )   // se o PCOM Bluetooth desconectou:
		{
			evento_Gerencia_BT = evento_nenhum;   // reseta indicador de evento.

			evento_Cliente_BT = evento_desconectou_BT;   // gera evento indicando que Cliente BT desconectou.

			PCOM_atual = PCOM_nenhum;   // registra que nao ha' PCOM ativo.

			ESTADO_CONEXAO = estado_SYS_bloquear_BT;   // vai para o estado "bloquear dados BT".
		}
		else if ( evento_Cliente_BT == evento_Cliente_Aut_BT )   // se o Cliente Bluetooth autenticou:
		{
			evento_Cliente_BT = evento_nenhum;   // reseta indicador de evento.

			ESTADO_CONEXAO = estado_SYS_permitir_BT;   // vai para o estado "permitir dados BT".
		}
		else if ( evento_Cliente_BT == evento_Cliente_NoAut_BT )   // se o Cliente Bluetooth NAO autenticou:
		{
			evento_Cliente_BT = evento_nenhum;   // reseta indicador de evento.

			evento_Gerencia_BT = evento_desconectar_BT;  // gera evento para desconectar o PCOM Bluetooth.
		}
	}

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_permitir_BT )   // se esta' no estado "permitir dados BT":
	{
		PCOM_BTC_pass = true;   // valida Autenticacao do PCOM Bluetooth.

		ESTADO_CONEXAO = estado_SYS_PCOM_BT;   // vai para o estado "PCOM BT ativo".
	}

//..................................................

	if ( ESTADO_CONEXAO == estado_SYS_bloquear_BT )   // se esta' no estado "bloquear dados BT":
	{
		PCOM_BTC_pass = false;   // invalida Autenticacao do PCOM Bluetooth.

		evento_Gerencia_WiFi = evento_conectar_WF;  // gera evento para iniciar o PCOM WiFi.

		ESTADO_CONEXAO = estado_SYS_espera_WF;   // vai para o estado "esperando PCOM WiFi".
	}

//..................................................

	DEBUG_line( SYS_STATUS_view( ESTADO_CONEXAO ) );   // informa estado atual (via Debug).

	PCOM_allow_check();   // atualiza status de permissao de conexao via PCOMs do Sistema.
}
//***********************************************************************




//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\
//
//	Rotinas para suporte da Interface com o Codigo do Arduino.
//
//\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\




//***********************************************************************
//	Especifica os parametros principais para configuracao do
//	PCOM WiFi. Estes parametros sao especificados atraves de
//	uma estrutura "WiFi_PCOM_info", a qual contem o Nome e a
//	Senha da Rede WiFi onde o Sistema se conectara', alem do
//	numero da Porta TCP/IP para acesso ao instanciamento do
//	WiFi Server usado no PCOM WiFi.
//=======================================================================

void	define_parametros_PCOM_WiFi ( WiFi_PCOM_info* WiFi_info_PTR )
{
//--------------------------------------------------
String texto;
//--------------------------------------------------

	if ( (*WiFi_info_PTR).nome_WiFi.length() != 0 )  // se especificou a rede WiFi:
	{
		texto = (*WiFi_info_PTR).nome_WiFi;   // obtem o nome especificado.

		texto.substring( 0, 16 );   // limita o nome em 16 caracteres.

		WiFi_ssid = texto;   // seta o nome para a Rede WiFi.
	}

//..................................................

	if ( (*WiFi_info_PTR).senha_WiFi.length() != 0 )  // se especificou a senha WiFi:
	{
		texto = (*WiFi_info_PTR).senha_WiFi;   // obtem a senha especificada.

		texto.substring( 0, 16 );   // limita a senha em 16 caracteres.

		WiFi_password = texto;   // seta a senha para a Rede WiFi.
	}

//..................................................

	if ( (*WiFi_info_PTR).server_PORT != 0 )  // se especificou um Port:
	{
		WiFi_SERVER_PORT = (*WiFi_info_PTR).server_PORT;  // seta o Port para o WiFi Server.
	}

//..................................................

	DEBUG_start();  // inicia bloco de Debug.

	Serial.println();

	Serial.print( F("rede WiFi: ") );   // informa no Terminal, o nome da Rede WiFi.
	Serial.println( WiFi_ssid );

	Serial.print( F("senha WiFi: ") );   // informa no Terminal, a senha da Rede WiFi.
	Serial.println( WiFi_password );

	Serial.print( F("Porta do Server: ") );  // informa no Terminal, o Port do WiFi Server.
	Serial.println( WiFi_SERVER_PORT );

	Serial.println();

	DEBUG_end();   // finaliza bloco de Debug.
}
//***********************************************************************




//***********************************************************************
//	Especifica os parametros principais para configuracao do
//	PCOM Bluetooth. Estes parametros sao especificados atraves
//	de uma estrutura "BTC_PCOM_info", a qual contem o Nome do
//	"Bluetooth Device" (nome do Dispositivo Bluetooth para este
//	Sistema) e a Senha para Autenticacao de Clientes Bluetooth.
//	neste Sistema.
//=======================================================================

void	define_parametros_PCOM_Bluetooth ( BTC_PCOM_info* BTC_info_PTR )
{
//--------------------------------------------------
String texto;
//--------------------------------------------------

	if ( (*BTC_info_PTR).nome_Bluetooth.length() != 0 )  // se especificou o nome Bluetooth:
	{
		texto = (*BTC_info_PTR).nome_Bluetooth;   // obtem o nome especificado.

		texto.substring( 0, 16 );   // limita o nome em 16 caracteres.

		nome_BLUETOOTH = texto;   // seta o nome para o "Bluetooth Device".
	}

//..................................................

	if ( (*BTC_info_PTR).senha_Bluetooth.length() != 0 )  // se especificou senha de Autenticacao:
	{
		texto = (*BTC_info_PTR).senha_Bluetooth;   // obtem a senha especificada.

		texto.substring( 0, 16 );   // limita a senha em 16 caracteres.

		BTC_password = texto;   // seta a senha de Autenticacao de Clientes Bluetooth.
	}

//..................................................

	DEBUG_start();  // inicia bloco de Debug.

	Serial.println();

	Serial.print( F("nome Bluetooth: ") );   // informa no Terminal, o nome do "Bluetooth Device".
	Serial.println( nome_BLUETOOTH );

	Serial.print( F("senha Bluetooth: ") );  // informa no Terminal, a senha de Autenticacao Bluetooth.
	Serial.println( BTC_password );

	Serial.println();

	DEBUG_end();   // finaliza bloco de Debug.
}
//***********************************************************************




//***********************************************************************
//	Funcao para setar o status atual de permissao da conexao via
//	PCOM WiFi.
//	Se a conexao nao e' permitida, entao o PCOM WiFi nao sera'
//	utilizado para estabelecer uma conexao no Sistema, e neste
//	caso se o PCOM WiFi estiver atualmente conectado entao ele
//	sera' desconectado.
//	Se a conexao e' permitida, o PCOM WiFi podera' ser utilizado
//	para estabelecer uma conexao no Sistema. Neste caso, tambem
//	sera' rotineiramente verificado se foi enviado algum comando
//	via Debug para controle do PCOM WiFi.
//	A permissao pode ser alterada a qualquer momento, ou seja, e'
//	do tipo "on the fly".
//=======================================================================

void	controla_Permissao_PCOM_WiFi ( bool WiFi_allow )
{
	PCOM_WiFi_allow = WiFi_allow;  // seta status de permissao de conexao via PCOM WiFi.
}
//***********************************************************************




//***********************************************************************
//	Funcao para setar o status atual de permissao da conexao via
//	PCOM Bluetooth.
//	Se a conexao nao e' permitida, entao o PCOM Bluetooth nao sera'
//	utilizado para estabelecer uma conexao no Sistema, e neste caso
//	se o PCOM Bluetooth estiver atualmente conectado entao ele sera'
//	desconectado.
//	Se a conexao e' permitida, o PCOM Bluetooth podera' ser utilizado
//	para estabelecer uma conexao no Sistema. Neste caso, tambem sera'
//	rotineiramente verificado se foi enviado algum comando via Debug
//	para controle do PCOM Bluetooth.
//	A permissao pode ser alterada a qualquer momento, ou seja, e'
//	do tipo "on the fly".
//=======================================================================

void	controla_Permissao_PCOM_Bluetooth ( bool BTC_allow )
{
	PCOM_BTC_allow = BTC_allow;  // seta status de permissao de conexao via PCOM BT.
}
//***********************************************************************




//***********************************************************************
//	Especifica o timeout para se esperar a conexao da rede WiFi.
//	Para facilitar o uso, o timeout e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_Timeout_conexao_WiFi ( unsigned short timeout )
{
//--------------------------------------------------
unsigned long  timeout_ms;
//--------------------------------------------------

	timeout_ms = (unsigned long) 1000 * timeout;  // calcula em [ms].

	if ( timeout_ms < 5000 ) timeout_ms = 5000;   // garante periodo minimo.

	WiFi_timeout = timeout_ms;   // seta o novo periodo do "WiFi timeout".
}
//***********************************************************************




//***********************************************************************
//	Especifica o timeout para espera da Configuracao Bluetooth e
//	da conexao de um Cliente Bluetooth.
//	Para facilitar o uso, o timeout e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_Timeout_conexao_Bluetooth ( unsigned short timeout )
{
//--------------------------------------------------
unsigned long  timeout_ms;
//--------------------------------------------------

	timeout_ms = (unsigned long) 1000 * timeout;  // calcula em [ms].

	if ( timeout_ms < 8000 ) timeout_ms = 8000;   // garante periodo minimo.

	BT_timeout = timeout_ms;   // seta o novo periodo do "BT timeout".
}
//***********************************************************************




//***********************************************************************
//	Especifica o Modo de Comando utilizado no envio/recebimento
//	de comandos atraves do PCOM Bluetooth.
//	Para uma Lista dos Comandos implementados e respectiva descricao
//	destes comandos, consultar documentacao especifica, ou na forma
//	de comentarios neste codigo.
//	Embora o Modo de Comando possa ser alterado a qualquer momento
//	("on the fly"), em geral isso e' feito apenas na inicializacao
//	do Sistema.
//=======================================================================

void	define_Modo_Comando_PCOM_Bluetooth	( byte CMD_Mode )
{
	switch ( CMD_Mode )  // conforme o Modo de Comando especificado:
	{
		case BT_CMD_simples:  // se especificou "modo simples":

			BT_CMD_mode = BT_CMD_simples;  // seta "modo simples".

		break;
//..................................................

		case BT_CMD_texto:  // se especificou "modo texto":

			BT_CMD_mode = BT_CMD_texto;  // seta "modo texto".

		break;
//..................................................

		default:  // se o modo especificado nao esta' implementado:

			DEBUG_start();  // inicia bloco de Debug.

			Serial.println();
			Serial.print( F("Modo de Comando BT invalido !!! ") );
			Serial.println();

			DEBUG_end();   // finaliza bloco de Debug.
//..................................................
	}
}
//***********************************************************************




//***********************************************************************
//	Especifica o numero maximo de tentativas de insercao da
//	senha de Autenticacao de um Cliente Bluetooth, quando a
//	senha inserida e' invalida.
//	Apos este numero de tentativas, o Cliente tera' que esperar
//	o tempo definido pelo "intervalo de Autenticacao" antes da
//	proxima tentativa de Autenticacao.
//=======================================================================

void	define_tentativas_Senha_Bluetooth ( byte tentativas )
{
	if ( tentativas < 1 ) tentativas = 1;   // impede numero incoerente.

	MAX_tent_Senha_Autentic_BT = tentativas;   // seta o numero de tentativas.

	valida_Timeout_Autentic_BT();   // garante timeout coerente com as tentativas.
}
//***********************************************************************




//***********************************************************************
//	Especifica o timeout para a insercao da senha de Autenticacao
//	de um Cliente Bluetooth. Este timeout se refere ao numero
//	maximo de tentativas. Exemplo: se foi especificado um maximo
//	de 3 tentativas, o Cliente tera' o tempo de timeout para fazer
//	estas 3 tentativas. O Sistema garante um minimo de 15 segundos
//	para cada tentativa, de forma que se o valor de timeout for
//	incoerente com isso, este timeout sera' recalculado para que
//	fique coerente com esta regra.
//	Este timeout e' chamado de "timeout de Autenticacao".
//	Para facilitar o uso, o timeout e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_Timeout_Autenticar_Bluetooth ( unsigned short timeout )
{
//--------------------------------------------------
unsigned long  timeout_ms;
//--------------------------------------------------

	timeout_ms = (unsigned long) 1000 * timeout;  // calcula em [ms].

	Timeout_Autentic_BT = timeout_ms;   // seta o novo timeout.

	valida_Timeout_Autentic_BT();   // garante timeout coerente com as tentativas.
}
//***********************************************************************




//***********************************************************************
//	Especifica o intervalo de tempo ate' a proxima tentativa de
//	Autenticacao de um Cliente Bluetooth, apos este Cliente ter
//	feito o maximo de tentativas atualmente definido. Logo, se um
//	Cliente fez todas as tentativas inserindo senhas incorretas,
//	ele tera' que esperar este intervalo de tempo ate' que possa
//	fazer novas tentativas. Isto tambem ocorre se o Cliente se
//	desconectar durante o processo de Autenticacao.
//	Este intervalo e' chamado de "intervalo de Autenticacao".
//	Para facilitar o uso, o intervalo e' especificado em unidades de
//	segundos, e pode ser alterado a qualquer momento ("on the fly").
//=======================================================================

void	define_intervalo_Autenticar_Bluetooth ( unsigned short intervalo )
{
//--------------------------------------------------
unsigned long  intervalo_ms;
//--------------------------------------------------

	intervalo_ms = (unsigned long) 1000 * intervalo;  // calcula em [ms].

	intervalo_Autentic_BT = intervalo_ms;   // seta o novo intervalo.
}
//***********************************************************************




//***********************************************************************
//	Reseta a Lista de Clientes Bluetooth autenticados neste
//	Sistema. Na saida, a funcao informe se a Lista foi resetada.
//
//	Atencao: se o PCOM ativo for o PCOM Bluetooth, entao a Lista
//	nao sera' resetada.
//=======================================================================

bool	reseta_Lista_Autenticar_Bluetooth ()
{
//--------------------------------------------------
bool Ok = false;
//--------------------------------------------------

	if ( PCOM_atual != PCOM_BTC )   // se o PCOM Bluetooth nao esta' ativo:
	{
		BT_Client_list_RESET();   // reseta a Lista de Clientes Bluetooth.

		DEBUG_start();  // inicia bloco de Debug.
		Serial.println();
		Serial.println( F("resetou Lista BT !!!") );
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.

		Ok = true;   // indica que a Lista foi resetada.
	}
	else   // se o PCOM Bluetooth esta' ativo, informa via Terminal:
	{
		DEBUG_start();  // inicia bloco de Debug.
		Serial.println();
		Serial.println( F("para resetar a Lista, desconecte o BT !!!") );
		Serial.println();
		DEBUG_end();   // finaliza bloco de Debug.
	}

	return ( Ok );   // informa se a Lista foi resetada.
}
//***********************************************************************




//***********************************************************************
//	Seta o timeout para atendimento a um Cliente HTML. O periodo
//	e' especificado em unidades de segundos, para facilidade de
//	utilizacao da rotina. O timeout pode ser alterado a qualquer
//	momento ("on the fly").
//
//	Parametros:
//	- segundos = periodo do timeout, em segundos.
//=======================================================================

void	define_timeout_HTML_WiFi ( unsigned short segundos )
{
	WF_HTML_timeout_set( segundos );   // seta o timeout.
}
//***********************************************************************




//***********************************************************************
//	Gerencia Paginas HTML para um Cliente conectado via WiFi.
//	Essencialmente, a rotina gerencia a recepcao de requisicoes
//	do Cliente (se um estiver conectado). Quando uma requisicao
//	e' completada, a rotina chama a funcao que ira' processar a
//	requisicao do Cliente, passando para esta funcao a string que
//	corresponde a requisicao (esta string normalmente e' enviada
//	pelo navegador utilizado pelo Cliente). A funcao a ser chamada
//	(em um formato semelhante a um "callback"), e' passada para
//	esta rotina por quem chamou a mesma, juntamente com o Cliente
//	atual. Um timeout tambem esta' implementado, para o caso do
//	Cliente nao concluir a requisicao iniciada. Quando o timeout
//	ocorre, a requisicao e' descartada e a conexao com o Cliente
//	e' fechada, mas podera' ser reaberta se o Cliente reconectar.
//	Na saida, a rotina informa se alguma requisicao foi recebida.
//
//	Parametros:
//	- client_PTR = Ponteiro para o Cliente WiFi.
//	- HTML_Proc = funcao que ira' processar a Pagina HTML.
//
//	Saida:
//	- true = a rotina recebeu uma requisicao do Cliente WiFi.
//	- false = a rotina NAO recebeu uma requisicao do Cliente WiFi.
//=======================================================================

bool	WiFi_HTML_Client_Manager ( WiFiClient* client_PTR, HTML_Processor HTML_Proc )
{
	return ( WF_HTML_Manager( client_PTR, HTML_Proc ) );  // gerencia Paginas HTML.
}
//***********************************************************************




//***********************************************************************
//	Verifica se o PCOM WiFi esta' disponivel para comunicacao.
//	O codigo atualmente em execucao no Arduino, deve verificar
//	se o PCOM WiFi esta' disponivel antes de qualquer processo
//	de comunicacao com um Cliente WiFi. A verificacao deve ser
//	periodica, uma vez que a Rede WiFi utilizada como meio de
//	comunicacao, pode nao estar mais disponivel em um momento
//	qualquer (por exemplo, na ausencia de energia).
//
//	Obs.:
//	Esta disponibilidade, NAO indica que um Cliente WiFi fez uma
//	Autenticacao neste Sistema. Assim, qualquer Autenticacao do
//	Cliente, deve ser implementada no codigo do Arduino, o que
//	permite uma grande flexibilidade no nivel de seguranca para
//	um controle via WiFi.
//=======================================================================

bool	WiFi_disponivel ()
{
	return ( PCOM_WiFi_pass );   // informa se o WiFi esta' disponivel.
}
//***********************************************************************




//***********************************************************************
//	Verifica se o PCOM Bluetooth esta' disponivel para comunicacao.
//	O codigo atualmente em execucao no Arduino, deve verificar se
//	o PCOM Bluetooth esta' disponivel antes de qualquer processo de
//	comunicacao com um Cliente Bluetooth. Esta verificacao deve ser
//	periodica, uma vez que a Rede Bluetooth utilizada como meio de
//	comunicacao, pode nao estar mais disponivel em qualquer momento,
//	ou o Cliente Bluetooth pode ter se desconectado repentinamente.
//
//	Obs.:
//	Esta disponibilidade INDICA que o Cliente passou pelo processo
//	de Autenticacao Bluetooth (atraves de senha de Autenticacao).
//=======================================================================

bool	Bluetooth_disponivel ()
{
	return ( PCOM_BTC_pass );  // informa se o Bluetooth esta' disponivel.
}
//***********************************************************************




//***********************************************************************
//	Obtem um eventual Cliente que esteja tambem conectado na
//	mesma Rede WiFi na qual este Sistema esta' conectado. Se
//	houver um Cliente WiFi conectado, este Cliente pode entao
//	se comunicar com o codigo do Arduino atualmente em execucao.
//	A comunicacao pode ser por Paginas HTML (ou seja, protocolo
//	"http"), ou qualquer outro protocolo padrao ou dedicado.
//	Qualquer Autenticacao do Cliente, deve ser implementada no
//	codigo do Arduino, permitindo assim grande flexibilidade no
//	nivel de seguranca para um controle via WiFi.
//
//	Obs.:
//	O Cliente WiFi, e' da mesma Classe "WiFi" da implementacao
//	do ESP32 para a plataforma Arduino, e portanto tem as mesmas
//	funcionalidades de um Cliente da Classe "WiFi", incluindo as
//	funcionalidades da Classe "Stream" e da Classe "Print".
//=======================================================================

WiFiClient   obtem_Cliente_WiFi ()
{
	return ( System_WiFi_server.available() );  // retorna Cliente WiFi.
}
//***********************************************************************




//***********************************************************************
//	Obtem Ponteiro para a Interface SPP Bluetooth do Sistema.
//	Atraves deste Ponteiro o codigo do Arduino atualmente em
//	execucao, pode se comunicar com um Cliente Bluetooth via
//	Interface SPP instanciada no Sistema (e' possivel apenas
//	uma unica instancia SPP).
//	A comunicacao nao tem um protocolo padrao definido, assim
//	o usuario pode implementar essa comunicacao da forma que
//	considerar mais adequada para a intencao de uso.
//	Mas para o Cliente poder acessar o controle deste Sistema,
//	ele deve antes ter passado pelo processo de Autenticacao
//	Bluetooth, o que acrescenta um nivel de seguranca atraves
//	de uma senha de Autenticacao.
//
//	Obs.:
//	Esta Interface SPP Bluetooth, tem as mesmas funcionalidades
//	da Classe "BluetoothSerial" da implementacao do ESP32 para
//	a plataforma Arduino, e portanto tem as funcionalidades da
//	Classe "Stream" e da Classe "Print".
//=======================================================================

BLUE_Device_PTR   obtem_SPP_Bluetooth_PTR ()
{
//--------------------------------------------------
BLUE_Device_PTR  SPP_PTR;
//--------------------------------------------------

	if ( PCOM_BTC_pass )  // se o Cliente atual esta' autenticado:
	{
		SPP_PTR = &System_SPP;   // obtem o Ponteiro para a SPP do Sistema.
	}
	else	SPP_PTR = NULL;   // do contrario, invalida o Ponteiro.

	return ( SPP_PTR );   // retorna Ponteiro para o SPP Bluetooth.
}
//***********************************************************************




//***********************************************************************
//	Faz o cadenciamento da execucao das Maquinas de Estados que
//	gerenciam o PCOM WiFi/Bluetooth.
//	No processo, eventos sao trocados de forma direcionada entre
//	as Maquinas de Estados.
//=======================================================================

void	WiFi_Bluetooth_PCOM_Manager ()
{
	MAQUINA_gerencia_CONEXAO();   // executa a Maquina que gerencia a conexao deste Sistema.

//..................................................

	evento_Gerencia_WiFi = MAQUINA_gerencia_WiFi( evento_Gerencia_WiFi );  // executa Maquina que gerencia o PCOM WiFi.

	evento_Gerencia_BT = MAQUINA_gerencia_Bluetooth( evento_Gerencia_BT );  // executa Maquina que gerencia o PCOM Bluetooth.

	evento_Cliente_BT = MAQUINA_Cliente_BT( evento_Cliente_BT );  // executa Maquina que controla o acesso de Clientes Bluetooth.
}
//***********************************************************************



#endif	// _PCOM_WF_BTC_001_cpp_

